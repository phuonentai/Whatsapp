import React, { useEffect } from 'react';
import Head from 'next/head';
import Script from 'next/script';
import OnboardingInfoSectionCustomComponents1 from '../components/custom-components/OnboardingInfoSectionCustomComponents1';
import OnboardingInfoSectionCustomComponents2 from '../components/custom-components/OnboardingInfoSectionCustomComponents2';
import OnboardingInfoSectionCustomComponents3 from '../components/custom-components/OnboardingInfoSectionCustomComponents3';
import OnboardingInfoSectionCustomComponents4 from '../components/custom-components/OnboardingInfoSectionCustomComponents4';
import OnboardingInfoSectionCustomComponents5 from '../components/custom-components/OnboardingInfoSectionCustomComponents5';
import OnboardingInfoSectionCustomComponents6 from '../components/custom-components/OnboardingInfoSectionCustomComponents6';
import OnboardingInfoSectionCustomComponents7 from '../components/custom-components/OnboardingInfoSectionCustomComponents7';

const OnboardingInfo: React.FC = () => {
  useEffect(() => {
    // Custom CSS classes for elements from the index.html
    let classes = document.body.classList;
    document.body.classList.remove(...classes);
    document.body.classList.add(
      ...'antialiased font-body bg-body text-body bg-slate-50 text-slate-900'.split(
        ' '
      )
    );
    // Load custom component scripts after React components are mounted
    const script1 = document.createElement('script');
    script1.src =
      'js/global-104586.js';
    script1.async = true;
    document.head.appendChild(script1);
  }, []);

  return (
    <>
      <Head>
        <title>Onboarding — ChatFlow</title>
        <link
          rel='icon'
          type='image/png'
          sizes='32x32'
          href='/shuffle-for-bootstrap.png'
        />
      </Head>
      <OnboardingInfoSectionCustomComponents1 />
      <OnboardingInfoSectionCustomComponents2 />
      <OnboardingInfoSectionCustomComponents3 />
      <OnboardingInfoSectionCustomComponents4 />
      <OnboardingInfoSectionCustomComponents5 />
      <OnboardingInfoSectionCustomComponents6 />
      <OnboardingInfoSectionCustomComponents7 />
    </>
  );
};

export default OnboardingInfo;

