import React, { useEffect } from 'react';
import Head from 'next/head';
import Script from 'next/script';
import OnboardingSectionCustomComponents1 from '../components/custom-components/OnboardingSectionCustomComponents1';

const Onboarding: React.FC = () => {
  useEffect(() => {
    // Load custom component scripts after React components are mounted
    const script1 = document.createElement('script');
    script1.src =
      'js/1416946.js?v=1786546491';
    script1.async = true;
    document.head.appendChild(script1);
    const script2 = document.createElement('script');
    script2.src =
      'js/global-104586.js';
    script2.async = true;
    document.head.appendChild(script2);
  }, []);

  return (
    <>
      <Head>
        <title></title>
        <link
          rel='icon'
          type='image/png'
          sizes='32x32'
          href='/shuffle-for-bootstrap.png'
        />
      </Head>
      <OnboardingSectionCustomComponents1 />
    </>
  );
};

export default Onboarding;

