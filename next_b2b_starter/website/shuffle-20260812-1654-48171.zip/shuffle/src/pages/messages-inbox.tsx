import React, { useEffect } from 'react';
import Head from 'next/head';
import Script from 'next/script';
import MessagesInboxSectionCustomComponents1 from '../components/custom-components/MessagesInboxSectionCustomComponents1';
import MessagesInboxSectionCustomComponents2 from '../components/custom-components/MessagesInboxSectionCustomComponents2';
import MessagesInboxSectionCustomComponents3 from '../components/custom-components/MessagesInboxSectionCustomComponents3';

const MessagesInbox: React.FC = () => {
  useEffect(() => {
    // Custom CSS classes for elements from the index.html
    let classes = document.body.classList;
    document.body.classList.remove(...classes);
    document.body.classList.add(
      ...'antialiased font-body bg-body text-body bg-slate-50 text-slate-900'.split(
        ' '
      )
    );
    // Load custom component scripts after React components are mounted
    const script1 = document.createElement('script');
    script1.src =
      'js/global-104586.js';
    script1.async = true;
    document.head.appendChild(script1);
  }, []);

  return (
    <>
      <Head>
        <title>Messages Inbox — Verifika</title>
        <link
          rel='icon'
          type='image/png'
          sizes='32x32'
          href='/shuffle-for-bootstrap.png'
        />
      </Head>
      <MessagesInboxSectionCustomComponents1 />
      <MessagesInboxSectionCustomComponents2 />
      <MessagesInboxSectionCustomComponents3 />
    </>
  );
};

export default MessagesInbox;

