import React, { useEffect } from 'react';
import Head from 'next/head';
import Script from 'next/script';
import AiSettingsViewSectionCustomComponents1 from '../components/custom-components/AiSettingsViewSectionCustomComponents1';
import AiSettingsViewSectionCustomComponents2 from '../components/custom-components/AiSettingsViewSectionCustomComponents2';
import AiSettingsViewSectionCustomComponents3 from '../components/custom-components/AiSettingsViewSectionCustomComponents3';
import AiSettingsViewSectionCustomComponents4 from '../components/custom-components/AiSettingsViewSectionCustomComponents4';

const AiSettingsView: React.FC = () => {
  useEffect(() => {
    // Load custom component scripts after React components are mounted
    const script1 = document.createElement('script');
    script1.src =
      'js/global-104586.js';
    script1.async = true;
    document.head.appendChild(script1);
  }, []);

  return (
    <>
      <Head>
        <title>Ai Settings View — Verifika</title>
        <link
          rel='icon'
          type='image/png'
          sizes='32x32'
          href='/shuffle-for-bootstrap.png'
        />
      </Head>
      <AiSettingsViewSectionCustomComponents1 />
      <AiSettingsViewSectionCustomComponents2 />
      <AiSettingsViewSectionCustomComponents3 />
      <AiSettingsViewSectionCustomComponents4 />
    </>
  );
};

export default AiSettingsView;

