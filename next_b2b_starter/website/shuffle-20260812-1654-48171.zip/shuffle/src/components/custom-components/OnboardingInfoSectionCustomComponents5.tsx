import React from 'react';

const OnboardingInfoSectionCustomComponents5: React.FC = () => {
    return (
        <section className="py-20 lg:py-28 bg-slate-900 text-white">
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div className="grid lg:grid-cols-12 gap-12 items-center">
      <div className="lg:col-span-7">
        <span className="text-emerald-400 font-semibold text-sm uppercase tracking-wider">Cronograma típico</span>
        <h2 className="font-heading text-3xl sm:text-4xl font-bold mt-3 mb-4">
          Tu primera semana con ChatFlow
        </h2>
        <p className="text-lg text-slate-400 mb-10 max-w-2xl">
          Un plan claro desde la firma hasta el lanzamiento. Sin sorpresas, sin esperas innecesarias.
        </p>
        <div className="space-y-4">
          <div className="flex items-center gap-5 bg-slate-800 rounded-xl p-5 border border-slate-700 hover:border-emerald-500/50 transition-colors">
            <div className="w-16 text-center flex-shrink-0">
              <div className="text-emerald-400 font-heading font-bold text-lg">Día 1</div>
            </div>
            <div className="w-px h-10 bg-slate-700" />
            <div>
              <div className="font-semibold text-white">Kickoff y conexión de cuentas</div>
              <div className="text-sm text-slate-400">Llamada de bienvenida, verificación Meta y conexión de WhatsApp Business API.</div>
            </div>
          </div>
          <div className="flex items-center gap-5 bg-slate-800 rounded-xl p-5 border border-slate-700 hover:border-emerald-500/50 transition-colors">
            <div className="w-16 text-center flex-shrink-0">
              <div className="text-emerald-400 font-heading font-bold text-lg">Día 2</div>
            </div>
            <div className="w-px h-10 bg-slate-700" />
            <div>
              <div className="font-semibold text-white">IA entrenada e integración Siigo</div>
              <div className="text-sm text-slate-400">Copiloto configurado con tu catálogo y facturación DIAN validada con factura de prueba.</div>
            </div>
          </div>
          <div className="flex items-center gap-5 bg-slate-800 rounded-xl p-5 border border-slate-700 hover:border-emerald-500/50 transition-colors">
            <div className="w-16 text-center flex-shrink-0">
              <div className="text-emerald-400 font-heading font-bold text-lg">Día 3</div>
            </div>
            <div className="w-px h-10 bg-slate-700" />
            <div>
              <div className="font-semibold text-white">Capacitación del equipo y lanzamiento</div>
              <div className="text-sm text-slate-400">Sesión en vivo, usuarios creados y primeras conversaciones reales supervisadas.</div>
            </div>
          </div>
          <div className="flex items-center gap-5 bg-slate-800 rounded-xl p-5 border border-slate-700 hover:border-emerald-500/50 transition-colors">
            <div className="w-16 text-center flex-shrink-0">
              <div className="text-emerald-400 font-heading font-bold text-lg">Día 7</div>
            </div>
            <div className="w-px h-10 bg-slate-700" />
            <div>
              <div className="font-semibold text-white">Revisión de resultados</div>
              <div className="text-sm text-slate-400">Análisis de tiempos de respuesta, ventas cerradas y ajustes finos del Copiloto IA.</div>
            </div>
          </div>
        </div>
      </div>
      <div className="lg:col-span-5">
        <div className="relative">
          <div className="rounded-2xl overflow-hidden border border-slate-700 shadow-2xl">
            <img src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&w=1200&q=80" alt="Especialista acompañando a cliente en onboarding" className="w-full h-72 object-cover" />
          </div>
          <div className="relative -mt-16 mx-4 lg:mx-8 bg-slate-800 rounded-2xl border border-slate-700 p-6 shadow-xl">
            <div className="flex items-center gap-2 mb-4">
              <svg className="w-5 h-5 text-emerald-400" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
              </svg>
              <svg className="w-5 h-5 text-emerald-400" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
              </svg>
              <svg className="w-5 h-5 text-emerald-400" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
              </svg>
              <svg className="w-5 h-5 text-emerald-400" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
              </svg>
              <svg className="w-5 h-5 text-emerald-400" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
              </svg>
            </div>
            <p className="text-slate-300 text-sm leading-relaxed mb-4">
              "En dos días ya estábamos facturando desde WhatsApp. El especialista se encargó de todo con Siigo y Meta; nosotros solo vendimos."
            </p>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-500/20 rounded-full flex items-center justify-center">
                <span className="text-emerald-400 font-bold text-sm">CM</span>
              </div>
              <div>
                <div className="text-white font-semibold text-sm">Carlos Mendoza</div>
                <div className="text-slate-400 text-xs">Gerente Comercial, Distribuidora Andina</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


    );
};

export default OnboardingInfoSectionCustomComponents5;