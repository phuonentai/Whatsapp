import React from 'react';

const OnboardingInfoSectionCustomComponents2: React.FC = () => {
    return (
        <section className="relative bg-slate-900 text-white overflow-hidden">
  <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-900/20" />
  <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-emerald-500/10 to-transparent" />
  <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
    <div className="grid lg:grid-cols-12 gap-12 items-center">
      <div className="lg:col-span-6 space-y-8">
        <div className="inline-flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-4 py-2">
          <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
          <span className="text-emerald-400 text-sm font-medium">Activación en menos de 24 horas</span>
        </div>
        <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight tracking-tight">
          <span>Onboarding guiado para tu equipo de </span>
          <span className="text-emerald-400">ventas</span>
        </h1>
        <p className="text-lg sm:text-xl text-slate-300 leading-relaxed max-w-2xl">
          Conectamos tu número de WhatsApp, entrenamos al Copiloto IA con tu catálogo y activamos la facturación electrónica DIAN. Tú solo apruebas cada paso.
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <button className="bg-emerald-500 hover:bg-emerald-600 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all transform hover:scale-105 active:scale-95 shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2">
            Iniciar mi Onboarding
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
          </button>
          <button className="border-2 border-slate-600 hover:border-emerald-500 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all hover:bg-emerald-500/10 flex items-center justify-center gap-2"><svg className="w-5 h-5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
            Agendar Llamada
          </button>
        </div>
        <div className="pt-8 border-t border-slate-800">
          <div className="grid grid-cols-3 gap-6">
            <div>
              <div className="text-2xl lg:text-3xl font-bold text-emerald-400">24h</div>
              <div className="text-xs text-slate-400 mt-1">Tiempo promedio de activación</div>
            </div>
            <div>
              <div className="text-2xl lg:text-3xl font-bold text-emerald-400">98%</div>
              <div className="text-xs text-slate-400 mt-1">Clientes activos en la primera semana</div>
            </div>
            <div>
              <div className="text-2xl lg:text-3xl font-bold text-emerald-400">1:1</div>
              <div className="text-xs text-slate-400 mt-1">Especialista dedicado por cuenta</div>
            </div>
          </div>
        </div>
      </div>
      <div className="lg:col-span-6 relative">
        <div className="relative bg-slate-800 rounded-2xl border border-slate-700 shadow-2xl overflow-hidden">
          <div className="bg-slate-900 px-4 py-3 border-b border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500" />
              <div className="w-3 h-3 rounded-full bg-yellow-500" />
              <div className="w-3 h-3 rounded-full bg-emerald-500" />
            </div>
            <span className="text-xs text-slate-400 font-medium">Panel de Onboarding</span>
          </div>
          <div className="p-6 space-y-5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-white">Progreso de activación</span>
              <span className="text-sm font-bold text-emerald-400">75%</span>
            </div>
            <div className="w-full h-2 bg-slate-700 rounded-full overflow-hidden">
              <div className="h-full w-3/4 bg-gradient-to-r from-emerald-500 to-emerald-400 rounded-full" />
            </div>
            <div className="space-y-3 pt-2">
              <div className="flex items-center gap-4 bg-slate-900/60 rounded-xl p-4 border border-slate-700">
                <div className="w-9 h-9 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-white">WhatsApp Business verificado</div>
                  <div className="text-xs text-slate-400">Número +57 300 123 4567 conectado a Meta</div>
                </div>
                <span className="text-xs text-emerald-400 font-semibold">Listo</span>
              </div>
              <div className="flex items-center gap-4 bg-slate-900/60 rounded-xl p-4 border border-slate-700">
                <div className="w-9 h-9 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-white">Copiloto IA entrenado</div>
                  <div className="text-xs text-slate-400">142 productos y lista de precios importados</div>
                </div>
                <span className="text-xs text-emerald-400 font-semibold">Listo</span>
              </div>
              <div className="flex items-center gap-4 bg-emerald-500/10 rounded-xl p-4 border border-emerald-500/40">
                <div className="w-9 h-9 bg-emerald-500/20 border border-emerald-500/50 rounded-full flex items-center justify-center flex-shrink-0">
                  <svg className="w-4 h-4 text-emerald-400 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-white">Sincronizando con Siigo</div>
                  <div className="text-xs text-emerald-300/80">Validando resolución de facturación DIAN...</div>
                </div>
                <span className="text-xs text-emerald-400 font-semibold">En curso</span>
              </div>
              <div className="flex items-center gap-4 bg-slate-900/40 rounded-xl p-4 border border-slate-700/60 opacity-60">
                <div className="w-9 h-9 bg-slate-700 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-sm font-bold text-slate-400">4</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-slate-300">Capacitación del equipo</div>
                  <div className="text-xs text-slate-500">Sesión en vivo de 45 minutos</div>
                </div>
                <span className="text-xs text-slate-500 font-semibold">Pendiente</span>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute -bottom-6 -right-6 bg-white text-slate-900 rounded-xl p-4 shadow-xl border border-slate-200 hidden lg:block">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center">
              <svg className="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
            </div>
            <div>
              <div className="text-sm font-bold text-slate-900">Laura Gómez</div>
              <div className="text-xs text-slate-500">Tu especialista de onboarding</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


    );
};

export default OnboardingInfoSectionCustomComponents2;