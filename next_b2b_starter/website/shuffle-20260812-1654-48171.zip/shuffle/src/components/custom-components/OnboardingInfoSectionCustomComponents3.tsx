import React from 'react';

const OnboardingInfoSectionCustomComponents3: React.FC = () => {
    return (
        <section id="pasos" className="py-20 lg:py-28 bg-white">
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div className="max-w-3xl mb-16">
      <span className="text-emerald-600 font-semibold text-sm uppercase tracking-wider">Proceso paso a paso</span>
      <h2 className="font-heading text-3xl sm:text-4xl font-bold text-slate-900 mt-3 mb-4">
        Cuatro pasos, cero fricción técnica
      </h2>
      <p className="text-lg text-slate-600">
        Nuestro equipo se encarga de la configuración compleja. Tú solo necesitas aprobar cada etapa desde tu panel.
      </p>
    </div>
    <div className="grid lg:grid-cols-12 gap-8 lg:gap-12">
      <div className="lg:col-span-5 relative">
        <div className="lg:sticky lg:top-8">
          <div className="relative rounded-2xl overflow-hidden border border-slate-200 shadow-xl">
            <img src="https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1200&q=80" alt="Equipo de ventas en sesión de onboarding" className="w-full h-80 lg:h-[480px] object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <div className="bg-white/10 backdrop-blur rounded-xl p-4 border border-white/20">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-500 rounded-full flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <div>
                    <div className="text-white font-semibold text-sm">Sesión en vivo incluida</div>
                    <div className="text-slate-300 text-xs">Acompañamiento por videollamada en cada etapa</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="lg:col-span-7">
        <div className="space-y-0">
          <div className="relative flex gap-6 pb-12">
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-emerald-500/25">
                <span className="font-heading font-bold text-white">1</span>
              </div>
              <div className="w-px flex-1 bg-slate-200 mt-4" />
            </div>
            <div className="pb-2">
              <div className="flex items-center gap-3 mb-2">
                <h3 className="font-heading text-xl font-bold text-slate-900">Conexión de WhatsApp Business</h3>
                <span className="bg-emerald-100 text-emerald-700 text-xs font-semibold px-2.5 py-1 rounded-full">~2 horas</span>
              </div>
              <p className="text-slate-600 leading-relaxed mb-4">
                Migramos tu número actual a la API oficial de WhatsApp Business y completamos la verificación de tu empresa ante Meta. Conservas tu número, tu historial y tu reputación.
              </p>
              <ul className="space-y-2 text-sm text-slate-600">
                <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                  Verificación de empresa en Meta Business
                </li>
                <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                  Migración sin pérdida de conversaciones
                </li>
              </ul>
            </div>
          </div>
          <div className="relative flex gap-6 pb-12">
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-emerald-500/25">
                <span className="font-heading font-bold text-white">2</span>
              </div>
              <div className="w-px flex-1 bg-slate-200 mt-4" />
            </div>
            <div className="pb-2">
              <div className="flex items-center gap-3 mb-2">
                <h3 className="font-heading text-xl font-bold text-slate-900">Entrenamiento del Copiloto IA</h3>
                <span className="bg-emerald-100 text-emerald-700 text-xs font-semibold px-2.5 py-1 rounded-full">~60 segundos</span>
              </div>
              <p className="text-slate-600 leading-relaxed mb-4">
                Sube tu catálogo de productos, lista de precios o historial de chats. La IA aprende tu tono de comunicación, políticas de envío y lógica de precios al instante.
              </p>
              <ul className="space-y-2 text-sm text-slate-600">
                <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                  Importación desde Excel, CSV o Siigo
                </li>
                <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                  Pruebas de respuesta en ambiente seguro
                </li>
              </ul>
            </div>
          </div>
          <div className="relative flex gap-6 pb-12">
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-emerald-500/25">
                <span className="font-heading font-bold text-white">3</span>
              </div>
              <div className="w-px flex-1 bg-slate-200 mt-4" />
            </div>
            <div className="pb-2">
              <div className="flex items-center gap-3 mb-2">
                <h3 className="font-heading text-xl font-bold text-slate-900">Integración Siigo y pasarelas de pago</h3>
                <span className="bg-emerald-100 text-emerald-700 text-xs font-semibold px-2.5 py-1 rounded-full">~4 horas</span>
              </div>
              <p className="text-slate-600 leading-relaxed mb-4">
                Conectamos tu cuenta de Siigo para emitir facturas electrónicas válidas ante la DIAN y activamos tus pasarelas: Bold, Wompi, PSE y Nequi.
              </p>
              <ul className="space-y-2 text-sm text-slate-600">
                <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                  Validación de resolución de facturación DIAN
                </li>
                <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                  Factura de prueba emitida y verificada
                </li>
              </ul>
            </div>
          </div>
          <div className="relative flex gap-6">
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 bg-slate-900 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                <svg className="w-5 h-5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                </svg>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h3 className="font-heading text-xl font-bold text-slate-900">Capacitación y lanzamiento</h3>
                <span className="bg-slate-900 text-white text-xs font-semibold px-2.5 py-1 rounded-full">45 min</span>
              </div>
              <p className="text-slate-600 leading-relaxed mb-4">
                Sesión en vivo con todo tu equipo comercial: bandeja multi-agente, asignación de conversaciones, supervisión y mejores prácticas de cierre por WhatsApp.
              </p>
              <ul className="space-y-2 text-sm text-slate-600">
                <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                  Grabación y material de apoyo incluidos
                </li>
                <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                  Acompañamiento durante los primeros 7 días
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


    );
};

export default OnboardingInfoSectionCustomComponents3;