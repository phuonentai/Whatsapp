import React from 'react';

const OnboardingInfoSectionCustomComponents4: React.FC = () => {
    return (
        <section id="requisitos" className="py-20 lg:py-28 bg-slate-50">
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div className="grid lg:grid-cols-12 gap-12">
      <div className="lg:col-span-5">
        <span className="text-emerald-600 font-semibold text-sm uppercase tracking-wider">Antes de empezar</span>
        <h2 className="font-heading text-3xl sm:text-4xl font-bold text-slate-900 mt-3 mb-4">
          Lo único que necesitas tener a la mano
        </h2>
        <p className="text-lg text-slate-600 mb-8">
          Prepara estos documentos y accesos para que tu activación no tenga pausas. Si te falta algo, tu especialista te ayuda a conseguirlo.
        </p>
        <div className="bg-slate-900 rounded-2xl p-6 lg:p-8 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/20 rounded-full -translate-y-1/2 translate-x-1/2" />
          <h3 className="font-heading text-lg font-bold mb-4 relative">Checklist interactivo</h3>
          <p className="text-slate-400 text-sm mb-6 relative">Marca lo que ya tienes listo y mira tu nivel de preparación.</p>
          <div className="space-y-3 relative">
            <label className="check-item flex items-center gap-3 bg-slate-800 rounded-lg p-3 cursor-pointer border border-slate-700 hover:border-emerald-500/50 transition-colors">
              <input type="checkbox" className="req-check w-4 h-4 accent-emerald-500" />
              <span className="text-sm text-slate-200">NIT y RUT de la empresa</span>
            </label>
            <label className="check-item flex items-center gap-3 bg-slate-800 rounded-lg p-3 cursor-pointer border border-slate-700 hover:border-emerald-500/50 transition-colors">
              <input type="checkbox" className="req-check w-4 h-4 accent-emerald-500" />
              <span className="text-sm text-slate-200">Acceso a Meta Business Suite</span>
            </label>
            <label className="check-item flex items-center gap-3 bg-slate-800 rounded-lg p-3 cursor-pointer border border-slate-700 hover:border-emerald-500/50 transition-colors">
              <input type="checkbox" className="req-check w-4 h-4 accent-emerald-500" />
              <span className="text-sm text-slate-200">Usuario administrador de Siigo</span>
            </label>
            <label className="check-item flex items-center gap-3 bg-slate-800 rounded-lg p-3 cursor-pointer border border-slate-700 hover:border-emerald-500/50 transition-colors">
              <input type="checkbox" className="req-check w-4 h-4 accent-emerald-500" />
              <span className="text-sm text-slate-200">Catálogo de productos o servicios</span>
            </label>
            <label className="check-item flex items-center gap-3 bg-slate-800 rounded-lg p-3 cursor-pointer border border-slate-700 hover:border-emerald-500/50 transition-colors">
              <input type="checkbox" className="req-check w-4 h-4 accent-emerald-500" />
              <span className="text-sm text-slate-200">Resolución de facturación DIAN</span>
            </label>
          </div>
          <div className="mt-6 relative">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-slate-300">Nivel de preparación</span>
              <span className="font-bold text-emerald-400 readiness-value">0%</span>
            </div>
            <div className="w-full h-2 bg-slate-700 rounded-full overflow-hidden">
              <div className="readiness-bar h-full w-0 bg-gradient-to-r from-emerald-500 to-emerald-400 rounded-full transition-all duration-500" />
            </div>
            <p className="readiness-msg text-xs text-slate-400 mt-3">Marca los elementos que ya tienes listos.</p>
          </div>
        </div>
      </div>
      <div className="lg:col-span-7">
        <div className="grid sm:grid-cols-2 gap-6">
          <div className="bg-white rounded-2xl p-6 border border-slate-200 hover:border-emerald-500/50 hover:shadow-lg transition-all group">
            <div className="w-12 h-12 bg-emerald-500/10 rounded-xl flex items-center justify-center mb-5 group-hover:bg-emerald-500/20 transition-colors">
              <svg className="w-6 h-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <h3 className="font-heading text-lg font-bold text-slate-900 mb-2">Documentos legales</h3>
            <p className="text-slate-600 text-sm leading-relaxed">NIT, RUT actualizado, certificados bancarios y cámara de comercio. Los usamos únicamente para la verificación de Meta y la configuración fiscal con la DIAN.</p>
          </div>
          <div className="bg-white rounded-2xl p-6 border border-slate-200 hover:border-emerald-500/50 hover:shadow-lg transition-all group sm:mt-8">
            <div className="w-12 h-12 bg-emerald-500/10 rounded-xl flex items-center justify-center mb-5 group-hover:bg-emerald-500/20 transition-colors">
              <svg className="w-6 h-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            </div>
            <h3 className="font-heading text-lg font-bold text-slate-900 mb-2">Accesos administrativos</h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              Permisos de administrador en Meta Business y Siigo. Nunca almacenamos contraseñas: las conexiones se hacen por API oficial con tokens seguros.
            </p>
          </div>
          <div className="bg-white rounded-2xl p-6 border border-slate-200 hover:border-emerald-500/50 hover:shadow-lg transition-all group">
            <div className="w-12 h-12 bg-emerald-500/10 rounded-xl flex items-center justify-center mb-5 group-hover:bg-emerald-500/20 transition-colors">
              <svg className="w-6 h-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
              </svg>
            </div>
            <h3 className="font-heading text-lg font-bold text-slate-900 mb-2">Información comercial</h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              Catálogo de productos, precios, políticas de envío y preguntas frecuentes de tus clientes. Con esto entrenamos al Copiloto IA.
            </p>
          </div>
          <div className="bg-white rounded-2xl p-6 border border-slate-200 hover:border-emerald-500/50 hover:shadow-lg transition-all group sm:mt-8">
            <div className="w-12 h-12 bg-emerald-500/10 rounded-xl flex items-center justify-center mb-5 group-hover:bg-emerald-500/20 transition-colors">
              <svg className="w-6 h-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
            <h3 className="font-heading text-lg font-bold text-slate-900 mb-2">Tu equipo de ventas</h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              Lista de asesores con sus correos corporativos para crear los usuarios multi-agente y definir roles de supervisión desde el día uno.
            </p>
          </div>
        </div>
        <div className="mt-8 bg-emerald-50 border border-emerald-200 rounded-2xl p-6 flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center flex-shrink-0">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
          </div>
          <div className="flex-1">
            <h3 className="font-heading font-bold text-slate-900">¿No tienes todo listo?</h3>
            <p className="text-slate-600 text-sm">No hay problema. Tu especialista de onboarding te guía para obtener la resolución DIAN o verificar tu empresa en Meta sin costo adicional.</p>
          </div>
          <button className="bg-slate-900 text-white px-6 py-3 rounded-lg font-semibold text-sm hover:bg-slate-800 transition-all transform hover:scale-105 active:scale-95 whitespace-nowrap">
            Hablar con un especialista
          </button>
        </div>
      </div>
    </div>
  </div>
</section>


    );
};

export default OnboardingInfoSectionCustomComponents4;