import React from 'react';

const IndexSectionCustomComponents5: React.FC = () => {
    return (
        <section id="precios" className="py-20 lg:py-28 bg-slate-50">
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div className="text-center max-w-3xl mx-auto mb-12">
      <h2 className="font-heading text-3xl sm:text-4xl font-bold text-slate-900 mb-4">
        Planes que escalan con tu negocio
      </h2>
      <p className="text-lg text-slate-600 mb-8">
        Sin contratos forzosos. Cancela cuando quieras.
      </p>
      <div className="inline-flex items-center bg-white rounded-lg p-1 border border-slate-200">
        <button className="billing-toggle px-4 py-2 rounded-md text-sm font-medium bg-slate-900 text-white" data-period="monthly">Mensual</button>
        <button className="billing-toggle px-4 py-2 rounded-md text-sm font-medium text-slate-600 hover:text-slate-900" data-period="yearly">Anual <span className="text-emerald-600 font-bold">-20%</span></button>
      </div>
    </div>
    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
      <div className="bg-white rounded-2xl p-6 border border-slate-200 flex flex-col">
        <div className="mb-6">
          <h3 className="font-heading text-lg font-bold text-slate-900">Gratis</h3>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-3xl font-bold text-slate-900">$0</span>
            <span className="text-slate-500 text-sm">COP/mes</span>
          </div>
        </div>
        <ul className="space-y-3 text-sm text-slate-600 flex-1">
          <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            1 Usuario
          </li>
          <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            Copiloto Básico
          </li>
          <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            API Meta propia
          </li>
        </ul>
        <button className="w-full mt-6 py-2.5 border border-slate-300 rounded-lg text-slate-700 font-semibold hover:bg-slate-50 transition-colors">
          Comenzar
        </button>
      </div>
      <div className="bg-white rounded-2xl p-6 border border-slate-200 flex flex-col">
        <div className="mb-6">
          <h3 className="font-heading text-lg font-bold text-slate-900">Starter</h3>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-3xl font-bold text-slate-900 price" data-monthly="$39" data-yearly="$31">$39</span>
            <span className="text-slate-500 text-sm">USD/mes</span>
          </div>
        </div>
        <ul className="space-y-3 text-sm text-slate-600 flex-1">
          <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            3 Usuarios
          </li>
          <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            IA Copiloto Ilimitada
          </li>
          <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            Base Conocimiento RAG
          </li>
          <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            Links Pago Bold/Wompi
          </li>
        </ul>
        <button className="w-full mt-6 py-2.5 border border-slate-300 rounded-lg text-slate-700 font-semibold hover:bg-slate-50 transition-colors">
          Comenzar
        </button>
      </div>
      <div className="bg-slate-900 rounded-2xl p-6 border-2 border-emerald-500 flex flex-col relative transform lg:scale-105 shadow-xl">
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-emerald-500 text-white text-xs font-bold px-3 py-1 rounded-full">
          MÁS POPULAR
        </div>
        <div className="mb-6">
          <h3 className="font-heading text-lg font-bold text-white">Growth Pro</h3>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-3xl font-bold text-white price" data-monthly="$119" data-yearly="$95">$119</span>
            <span className="text-slate-400 text-sm">USD/mes</span>
          </div>
        </div>
        <ul className="space-y-3 text-sm text-slate-300 flex-1">
          <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            10 Usuarios
          </li>
          <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            IA Auto-Piloto + Copiloto
          </li>
          <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            Integración Siigo (DIAN)
          </li>
          <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            Asignación de Asesores
          </li>
          <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            Analítica Avanzada
          </li>
        </ul>
        <button className="w-full mt-6 py-2.5 bg-emerald-500 text-white rounded-lg font-bold hover:bg-emerald-600 transition-colors">
          Probar Gratis
        </button>
      </div>
      <div className="bg-white rounded-2xl p-6 border border-slate-200 flex flex-col">
        <div className="mb-6">
          <h3 className="font-heading text-lg font-bold text-slate-900">Enterprise</h3>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-3xl font-bold text-slate-900">Custom</span>
          </div>
        </div>
        <ul className="space-y-3 text-sm text-slate-600 flex-1">
          <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            Usuarios ilimitados
          </li>
          <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            IA Personalizada
          </li>
          <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            SLA Soporte 24/7
          </li>
          <li className="flex items-center gap-2"><svg className="w-4 h-4 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            Ley 1581 Habeas Data
          </li>
        </ul>
        <button className="w-full mt-6 py-2.5 border border-slate-300 rounded-lg text-slate-700 font-semibold hover:bg-slate-50 transition-colors">
          Contactar
        </button>
      </div>
    </div>
  </div>
</section>


    );
};

export default IndexSectionCustomComponents5;