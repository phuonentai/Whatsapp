import React from 'react';

const IndexSectionCustomComponents4: React.FC = () => {
    return (
        <section id="caracteristicas" className="py-20 lg:py-28 bg-slate-900 text-white">
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div className="max-w-3xl mb-16">
      <h2 className="font-heading text-3xl sm:text-4xl font-bold mb-4">
        Todo lo que necesitas para vender por WhatsApp
      </h2>
      <p className="text-lg text-slate-400">
        Herramientas empresariales diseñadas específicamente para el mercado colombiano.
      </p>
    </div>
    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
      <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700 hover:border-emerald-500/50 transition-colors group">
        <div className="w-12 h-12 bg-emerald-500/20 rounded-xl flex items-center justify-center mb-6 group-hover:bg-emerald-500/30 transition-colors">
          <svg className="w-6 h-6 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
          </svg>
        </div>
        <h3 className="font-heading text-lg font-bold mb-3">Entrenamiento IA en 60s</h3>
        <p className="text-slate-400 text-sm leading-relaxed">
          Sube tu historial de chats o lista de precios. Nuestra IA aprende la logística, precios y tono de tu negocio en Colombia al instante.
        </p>
      </div>
      <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700 hover:border-emerald-500/50 transition-colors group">
        <div className="w-12 h-12 bg-emerald-500/20 rounded-xl flex items-center justify-center mb-6 group-hover:bg-emerald-500/30 transition-colors">
          <svg className="w-6 h-6 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
        </div>
        <h3 className="font-heading text-lg font-bold mb-3">Facturación Siigo 1-Clic</h3>
        <p className="text-slate-400 text-sm leading-relaxed">
          Genera y envía facturas oficiales de la DIAN sin salir de la conversación de WhatsApp. Integración directa con Siigo.
        </p>
      </div>
      <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700 hover:border-emerald-500/50 transition-colors group">
        <div className="w-12 h-12 bg-emerald-500/20 rounded-xl flex items-center justify-center mb-6 group-hover:bg-emerald-500/30 transition-colors">
          <svg className="w-6 h-6 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
          </svg>
        </div>
        <h3 className="font-heading text-lg font-bold mb-3">Pagos Automatizados</h3>
        <p className="text-slate-400 text-sm leading-relaxed">
          Envía botones de pago seguros PSE, Nequi, Bold y Wompi. Cierra ventas de inmediato mientras conversas con el cliente.
        </p>
      </div>
      <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700 hover:border-emerald-500/50 transition-colors group">
        <div className="w-12 h-12 bg-emerald-500/20 rounded-xl flex items-center justify-center mb-6 group-hover:bg-emerald-500/30 transition-colors">
          <svg className="w-6 h-6 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
          </svg>
        </div>
        <h3 className="font-heading text-lg font-bold mb-3">App Móvil PWA</h3>
        <p className="text-slate-400 text-sm leading-relaxed">
          Supervisa a todo tu equipo comercial desde tu computador o celular con nuestra app web instalable multi-agente.
        </p>
      </div>
    </div>
    <div className="mt-16 bg-gradient-to-r from-emerald-600 to-emerald-500 rounded-2xl p-8 lg:p-12">
      <div className="grid lg:grid-cols-2 gap-8 items-center">
        <div>
          <h3 className="font-heading text-2xl lg:text-3xl font-bold mb-4">
            Calcula cuánto estás perdiendo por digitación manual
          </h3>
          <p className="text-emerald-100 mb-6">
            Descubre el costo real de no automatizar tu WhatsApp empresarial.
          </p>
          <div className="space-y-6">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Conversaciones diarias</span>
                <span className="font-bold" id="conv-value">100</span>
              </div>
              <input type="range" min={50} max={1000} defaultValue={100} className="w-full h-2 bg-emerald-800 rounded-lg appearance-none cursor-pointer slider-conv accent-white" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Vendedores</span>
                <span className="font-bold" id="rep-value">5</span>
              </div>
              <input type="range" min={1} max={20} defaultValue={5} className="w-full h-2 bg-emerald-800 rounded-lg appearance-none cursor-pointer slider-rep accent-white" />
            </div>
          </div>
        </div>
        <div className="bg-white/10 backdrop-blur rounded-xl p-6 border border-white/20">
          <div className="text-center space-y-4">
            <div>
              <div className="text-4xl lg:text-5xl font-bold" id="hours-lost">40</div>
              <div className="text-emerald-100 text-sm">Horas perdidas por semana</div>
            </div>
            <div className="h-px bg-white/20" />
            <div>
              <div className="text-3xl lg:text-4xl font-bold" id="money-lost">$8.5M</div>
              <div className="text-emerald-100 text-sm">COP en ventas perdidas al mes</div>
            </div>
            <button className="w-full bg-white text-emerald-600 py-3 rounded-lg font-bold hover:bg-emerald-50 transition-colors mt-4">
              Recuperar este tiempo ahora
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


    );
};

export default IndexSectionCustomComponents4;