import React from 'react';

const OnboardingSectionCustomComponents1: React.FC = () => {
    return (
        <section id="onboarding" className="min-h-screen bg-slate-900 relative overflow-hidden">
  <div className="onboarding-container relative min-h-screen flex flex-col">
    {/* Progress Bar */}
    <div className="absolute top-0 left-0 right-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
              <img src="https://placehold.co/20x20/10b981/ffffff?text=CF" alt="ChatFlow" className="w-5 h-5 rounded" />
            </div>
            <span className="font-bold text-xl text-white">ChatFlow</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="step-indicator text-sm text-slate-400">
              Paso
              <span className="current-step">1</span>
              de
              <span className="total-steps">5</span>
            </span>
          </div>
        </div>
        <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
          <div className="progress-bar h-full bg-emerald-500 transition-all duration-500 ease-out rounded-full" style={{width: '20%'}} />
        </div>
      </div>
    </div>
    {/* Steps Container */}
    <div className="flex-1 flex items-center justify-center px-4 sm:px-6 lg:px-8 pt-20 pb-12">
      <div className="steps-wrapper w-full max-w-2xl relative">
        {/* Step 1: Welcome */}
        <div className="step-page active" data-step={1}>
          <div className="text-center">
            <div className="mb-8 relative">
              <div className="absolute inset-0 bg-emerald-500/20 blur-3xl rounded-full" />
              <img src="https://placehold.co/200x200/1e293b/10b981?text=Welcome" alt="Welcome" className="relative mx-auto w-32 h-32 rounded-2xl object-cover border-2 border-emerald-500/30 animate-float" />
            </div>
            <h1 className="font-heading text-3xl sm:text-4xl font-bold text-white mb-4 animate-fade-in-up">Bienvenido a ChatFlow</h1>
            <p className="text-lg text-slate-400 mb-8 max-w-md mx-auto animate-fade-in-up" style={{animationDelay: '0.1s'}}>El CRM nativo para WhatsApp que automatiza ventas y facturación electrónica para empresas en Colombia y LATAM.</p>
            <div className="space-y-4 animate-fade-in-up" style={{animationDelay: '0.2s'}}>
              <div className="flex items-center gap-3 justify-center text-slate-300">
                <img src="https://placehold.co/24x24/10b981/ffffff?text=1" alt="" className="w-6 h-6 rounded" />
                <span className="text-sm">Configura tu empresa en 3 minutos</span>
              </div>
              <div className="flex items-center gap-3 justify-center text-slate-300">
                <img src="https://placehold.co/24x24/10b981/ffffff?text=2" alt="" className="w-6 h-6 rounded" />
                <span className="text-sm">Conecta WhatsApp Business API</span>
              </div>
              <div className="flex items-center gap-3 justify-center text-slate-300">
                <img src="https://placehold.co/24x24/10b981/ffffff?text=3" alt="" className="w-6 h-6 rounded" />
                <span className="text-sm">Empieza a vender automatizado</span>
              </div>
            </div>
            <button className="step-next mt-10 bg-emerald-500 text-white px-8 py-3 rounded-lg font-bold hover:bg-emerald-600 transition-all duration-300 hover:scale-105 animate-fade-in-up" style={{animationDelay: '0.3s'}}>Comenzar ahora</button>
          </div>
        </div>
        {/* Step 2: Company Info */}
        <div className="step-page hidden" data-step={2}>
          <div className="bg-slate-800 rounded-2xl p-6 sm:p-8 border border-slate-700 p-8">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-12 bg-emerald-500/20 rounded-xl flex items-center justify-center">
                <img src="https://placehold.co/24x24/10b981/ffffff?text=B" alt="" className="w-6 h-6 rounded" />
              </div>
              <div>
                <h2 className="font-heading text-2xl font-bold text-white">Información de tu empresa</h2>
                <p className="text-slate-400 text-sm">Necesitamos estos datos para la facturación DIAN</p>
              </div>
            </div>
            <div className="space-y-5">
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Nombre de la empresa</label>
                  <input type="text" className="company-name w-full bg-slate-900 border border-slate-600 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors" placeholder="Ej: Mi Negocio SAS" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">NIT</label>
                  <input type="text" className="company-nit w-full bg-slate-900 border border-slate-600 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors" placeholder="900.XXX.XXX-X" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Tipo de régimen</label>
                <div className="grid grid-cols-2 gap-3">
                  <button className="regime-btn active bg-emerald-500/20 border-2 border-emerald-500 rounded-lg px-4 py-3 text-emerald-300 font-medium transition-all" data-value="simplificado">Simplificado</button>
                  <button className="regime-btn bg-slate-900 border-2 border-slate-600 rounded-lg px-4 py-3 text-slate-400 font-medium hover:border-slate-500 transition-all" data-value="comun">Régimen Común</button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Ciudad de operación</label>
                <select className="company-city w-full bg-slate-900 border border-slate-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-emerald-500 transition-colors">
                  <option value>Selecciona una ciudad</option>
                  <option value="bogota">Bogotá D.C.</option>
                  <option value="medellin">Medellín</option>
                  <option value="cali">Cali</option>
                  <option value="barranquilla">Barranquilla</option>
                  <option value="cartagena">Cartagena</option>
                </select>
              </div>
            </div>
            <div className="flex gap-3 mt-8">
              <button className="step-prev flex-1 border border-slate-600 text-slate-300 py-3 rounded-lg font-semibold hover:bg-slate-700 transition-colors">Atrás</button>
              <button className="step-next flex-1 bg-emerald-500 text-white py-3 rounded-lg font-bold hover:bg-emerald-600 transition-all duration-300 hover:scale-[1.02]">Continuar</button>
            </div>
          </div>
        </div>
        {/* Step 3: WhatsApp Connection */}
        <div className="step-page hidden" data-step={3}>
          <div className="bg-slate-800 rounded-2xl p-6 sm:p-8 border border-slate-700">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-12 bg-emerald-500/20 rounded-xl flex items-center justify-center">
                <img src="https://placehold.co/24x24/10b981/ffffff?text=WA" alt="" className="w-6 h-6 rounded" />
              </div>
              <div>
                <h2 className="font-heading text-2xl font-bold text-white">Conecta WhatsApp</h2>
                <p className="text-slate-400 text-sm">Usa tu número actual o uno nuevo</p>
              </div>
            </div>
            <div className="space-y-4 mb-6">
              <div className="whatsapp-option active cursor-pointer bg-emerald-500/10 border-2 border-emerald-500 rounded-xl p-5 transition-all hover:bg-emerald-500/20" data-option="existing">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center flex-shrink-0">
                    <img src="https://placehold.co/20x20/10b981/ffffff?text=1" alt="" className="w-5 h-5 rounded" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white mb-1">Migrar mi número actual</h3>
                    <p className="text-sm text-slate-400">Transfiere tu número de WhatsApp personal o business a la API oficial. Te guiamos paso a paso.</p>
                  </div>
                </div>
              </div>
              <div className="whatsapp-option cursor-pointer bg-slate-900 border-2 border-slate-600 rounded-xl p-5 transition-all hover:border-slate-500" data-option="new">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-slate-600 rounded-lg flex items-center justify-center flex-shrink-0">
                    <img src="https://placehold.co/20x20/475569/ffffff?text=2" alt="" className="w-5 h-5 rounded" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-white mb-1">Nuevo número de WhatsApp</h3>
                    <p className="text-sm text-slate-400">Obtén un número nuevo dedicado exclusivamente para tu negocio.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="phone-input-container">
              <label className="block text-sm font-medium text-slate-300 mb-2">Número de teléfono</label>
              <div className="flex gap-3">
                <span className="bg-slate-900 border border-slate-600 rounded-lg px-4 py-3 text-slate-400 font-medium">+57</span>
                <input type="tel" className="whatsapp-phone flex-1 bg-slate-900 border border-slate-600 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors" placeholder="300 123 4567" />
              </div>
            </div>
            <div className="flex gap-3 mt-8">
              <button className="step-prev flex-1 border border-slate-600 text-slate-300 py-3 rounded-lg font-semibold hover:bg-slate-700 transition-colors">Atrás</button>
              <button className="step-next flex-1 bg-emerald-500 text-white py-3 rounded-lg font-bold hover:bg-emerald-600 transition-all duration-300 hover:scale-[1.02]">Verificar número</button>
            </div>
          </div>
        </div>
        {/* Step 4: AI Training */}
        <div className="step-page hidden" data-step={4}>
          <div className="bg-slate-800 rounded-2xl p-6 sm:p-8 border border-slate-700">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-12 h-12 bg-emerald-500/20 rounded-xl flex items-center justify-center">
                <img src="https://placehold.co/24x24/10b981/ffffff?text=AI" alt="" className="w-6 h-6 rounded" />
              </div>
              <div>
                <h2 className="font-heading text-2xl font-bold text-white">Entrena tu IA</h2>
                <p className="text-slate-400 text-sm">En 60 segundos tu asistente aprende tu negocio</p>
              </div>
            </div>
            <div className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-3">¿Qué vendes?</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <button className="product-type-btn bg-slate-900 border-2 border-slate-600 rounded-lg px-3 py-3 text-slate-400 text-sm font-medium hover:border-slate-500 transition-all" data-type="retail">Retail / Tienda</button>
                  <button className="product-type-btn bg-slate-900 border-2 border-slate-600 rounded-lg px-3 py-3 text-slate-400 text-sm font-medium hover:border-slate-500 transition-all" data-type="services">Servicios</button>
                  <button className="product-type-btn bg-slate-900 border-2 border-slate-600 rounded-lg px-3 py-3 text-slate-400 text-sm font-medium hover:border-slate-500 transition-all" data-type="food">Restaurantes</button>
                  <button className="product-type-btn bg-slate-900 border-2 border-slate-600 rounded-lg px-3 py-3 text-slate-400 text-sm font-medium hover:border-slate-500 transition-all" data-type="health">Salud / Belleza</button>
                  <button className="product-type-btn bg-slate-900 border-2 border-slate-600 rounded-lg px-3 py-3 text-slate-400 text-sm font-medium hover:border-slate-500 transition-all" data-type="tech">Tecnología</button>
                  <button className="product-type-btn bg-slate-900 border-2 border-slate-600 rounded-lg px-3 py-3 text-slate-400 text-sm font-medium hover:border-slate-500 transition-all" data-type="other">Otro</button>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Descripción de tu negocio (la IA usará esto para responder)</label>
                <textarea className="ai-description w-full bg-slate-900 border border-slate-600 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-colors h-32 resize-none" placeholder="Ej: Vendemos ropa deportiva para mujeres en Bogotá. Envíos a todo Colombia. Precios desde $45.000. Horario: Lunes a Sábado 9am-7pm." defaultValue={""} />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">Sube tu lista de precios o catálogo (opcional)</label>
                <div className="upload-zone border-2 border-dashed border-slate-600 rounded-xl p-8 text-center hover:border-emerald-500/50 transition-colors cursor-pointer">
                  <img src="https://placehold.co/48x48/1e293b/64748b?text=Upload" alt="" className="w-12 h-12 mx-auto mb-3 rounded" />
                  <p className="text-sm text-slate-400">
                    Arrastra archivos aquí o
                    <span className="text-emerald-400">clica para subir</span>
                  </p>
                  <p className="text-xs text-slate-500 mt-1">PDF, Excel, o imágenes. Máx 10MB</p>
                </div>
              </div>
            </div>
            <div className="flex gap-3 mt-8">
              <button className="step-prev flex-1 border border-slate-600 text-slate-300 py-3 rounded-lg font-semibold hover:bg-slate-700 transition-colors">Atrás</button>
              <button className="step-next flex-1 bg-emerald-500 text-white py-3 rounded-lg font-bold hover:bg-emerald-600 transition-all duration-300 hover:scale-[1.02]">Entrenar IA</button>
            </div>
          </div>
        </div>
        {/* Step 5: Success */}
        <div className="step-page hidden" data-step={5}>
          <div className="text-center">
            <div className="mb-8 relative">
              <div className="absolute inset-0 bg-emerald-500/20 blur-3xl rounded-full animate-pulse-slow" />
              <div className="relative">
                <img src="https://placehold.co/160x160/10b981/ffffff?text=Done" alt="Success" className="mx-auto w-40 h-40 rounded-2xl object-cover border-2 border-emerald-500 animate-success-bounce" />
                <div className="absolute -bottom-2 -right-2 w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center border-4 border-slate-900">
                  <img src="https://placehold.co/20x20/10b981/ffffff?text=%E2%9C%93" alt="" className="w-6 h-6 rounded" />
                </div>
              </div>
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl font-bold text-white mb-4 animate-fade-in-up">¡Todo listo!</h2>
            <p className="text-lg text-slate-400 mb-6 max-w-md mx-auto animate-fade-in-up" style={{animationDelay: '0.1s'}}>Tu asistente de IA está entrenado y listo para atender clientes 24/7</p>
            <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700 max-w-sm mx-auto mb-8 animate-fade-in-up" style={{animationDelay: '0.2s'}}>
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-emerald-500/20 rounded-xl flex items-center justify-center">
                  <img src="https://placehold.co/24x24/10b981/ffffff?text=AI" alt="" className="w-6 h-6 rounded" />
                </div>
                <div className="text-left">
                  <div className="font-semibold text-white">Asistente ChatFlow</div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                    <span className="text-sm text-emerald-400">Activo</span>
                  </div>
                </div>
              </div>
              <div className="space-y-3 text-left">
                <div className="flex items-center gap-3 text-sm text-slate-300">
                  <img src="https://placehold.co/16x16/10b981/ffffff?text=%E2%9C%93" alt="" className="w-4 h-4 rounded" />
                  <span>WhatsApp Business API conectado</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-slate-300">
                  <img src="https://placehold.co/16x16/10b981/ffffff?text=%E2%9C%93" alt="" className="w-4 h-4 rounded" />
                  <span>Facturación Siigo configurada</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-slate-300">
                  <img src="https://placehold.co/16x16/10b981/ffffff?text=%E2%9C%93" alt="" className="w-4 h-4 rounded" />
                  <span>IA entrenada con tu catálogo</span>
                </div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 justify-center animate-fade-in-up" style={{animationDelay: '0.3s'}}>
              <button className="dashboard-btn bg-emerald-500 text-white px-8 py-3 rounded-lg font-bold hover:bg-emerald-600 transition-all duration-300 hover:scale-105">Ir al dashboard</button>
              <button className="border border-slate-600 text-slate-300 px-8 py-3 rounded-lg font-semibold hover:bg-slate-800 transition-colors">Ver tutorial</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    {/* Background Elements */}
    <div className="absolute top-1/4 left-0 w-72 h-72 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
    <div className="absolute bottom-1/4 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
  </div>
  <style dangerouslySetInnerHTML={{__html: "<![CDATA[@keyframes float { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-20px); } } @keyframes fade-in-up { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } } @keyframes success-bounce { 0% { transform: scale(0); opacity: 0; } 50% { transform: scale(1.1); } 70% { transform: scale(0.95); } 100% { transform: scale(1); opacity: 1; } } @keyframes pulse-slow { 0%, 100% { opacity: 0.4; } 50% { opacity: 0.8; } } @keyframes slide-in-right { from { opacity: 0; transform: translateX(50px); } to { opacity: 1; transform: translateX(0); } } @keyframes slide-in-left { from { opacity: 0; transform: translateX(-50px); } to { opacity: 1; transform: translateX(0); } } @keyframes slide-out-left { from { opacity: 1; transform: translateX(0); } to { opacity: 0; transform: translateX(-50px); } } @keyframes slide-out-right { from { opacity: 1; transform: translateX(0); } to { opacity: 0; transform: translateX(50px); } } .animate-float { animation: float 6s ease-in-out infinite; } .animate-fade-in-up { animation: fade-in-up 0.6s ease-out forwards; opacity: 0; } .animate-success-bounce { animation: success-bounce 0.8s ease-out forwards; } .animate-pulse-slow { animation: pulse-slow 3s ease-in-out infinite; } .step-page { transition: all 0.5s ease-out; } .step-page.enter-right { animation: slide-in-right 0.5s ease-out forwards; } .step-page.enter-left { animation: slide-in-left 0.5s ease-out forwards; } .step-page.exit-left { animation: slide-out-left 0.5s ease-out forwards; position: absolute; width: 100%; top: 0; } .step-page.exit-right { animation: slide-out-right 0.5s ease-out forwards; position: absolute; width: 100%; top: 0; } .upload-zone.drag-over { border-color: #10b981; background: rgba(16, 185, 129, 0.1); } .slider-conv::-webkit-slider-thumb, .slider-rep::-webkit-slider-thumb { appearance: none; width: 20px; height: 20px; border-radius: 50%; background: white; cursor: pointer; }]]>" }} />
</section>


    );
};

export default OnboardingSectionCustomComponents1;