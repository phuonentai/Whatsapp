import React from 'react';

const OnboardingInfoSectionCustomComponents1: React.FC = () => {
    return (
        <nav className="bg-slate-900 text-white border-b border-slate-800">
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div className="flex items-center justify-between h-16">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
          <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
          </svg>
        </div>
        <span className="font-heading font-bold text-xl tracking-tight">ChatFlow</span>
      </div>
      <div className="hidden md:flex items-center gap-8">
        <a href="#pasos" className="text-sm text-slate-300 hover:text-white transition-colors">Pasos</a>
        <a href="#requisitos" className="text-sm text-slate-300 hover:text-white transition-colors">Requisitos</a>
        <a href="#faq" className="text-sm text-slate-300 hover:text-white transition-colors">FAQ</a>
        <button className="bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-all transform hover:scale-105 active:scale-95">
          Comenzar Onboarding
        </button>
      </div>
      <button className="md:hidden mobile-menu-btn p-2">
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>
    </div>
  </div>
  <div className="mobile-menu hidden md:hidden bg-slate-800 border-t border-slate-700">
    <div className="px-4 py-4 space-y-3">
      <a href="#pasos" className="block text-slate-300 hover:text-white py-2">Pasos</a>
      <a href="#requisitos" className="block text-slate-300 hover:text-white py-2">Requisitos</a>
      <a href="#faq" className="block text-slate-300 hover:text-white py-2">FAQ</a>
      <button className="w-full bg-emerald-500 text-white px-5 py-3 rounded-lg font-semibold mt-4">
        Comenzar Onboarding
      </button>
    </div>
  </div>
</nav>


    );
};

export default OnboardingInfoSectionCustomComponents1;