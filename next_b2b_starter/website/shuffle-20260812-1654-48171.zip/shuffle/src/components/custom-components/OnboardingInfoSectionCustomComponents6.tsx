import React from 'react';

const OnboardingInfoSectionCustomComponents6: React.FC = () => {
    return (
        <section id="faq" className="py-20 lg:py-28 bg-white">
  <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
    <div className="text-center mb-12">
      <h2 className="font-heading text-3xl sm:text-4xl font-bold text-slate-900 mb-4">
        Preguntas sobre el Onboarding
      </h2>
      <p className="text-lg text-slate-600">
        Todo lo que necesitas saber antes de activar tu cuenta.
      </p>
    </div>
    <div className="space-y-4">
      <div className="faq-item border border-slate-200 rounded-xl overflow-hidden">
        <button className="faq-toggle w-full px-6 py-4 text-left flex items-center justify-between hover:bg-slate-50 transition-colors">
          <span className="font-semibold text-slate-900">¿Cuánto tiempo toma todo el proceso de onboarding?</span>
          <svg className="w-5 h-5 text-slate-500 transform transition-transform faq-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        <div className="faq-content hidden px-6 pb-4 text-slate-600">
          El 90% de nuestros clientes queda completamente activo en menos de 24 horas hábiles. Si tu empresa ya tiene la verificación de Meta y la resolución DIAN, el proceso puede completarse el mismo día.
        </div>
      </div>
      <div className="faq-item border border-slate-200 rounded-xl overflow-hidden">
        <button className="faq-toggle w-full px-6 py-4 text-left flex items-center justify-between hover:bg-slate-50 transition-colors">
          <span className="font-semibold text-slate-900">¿El onboarding tiene algún costo adicional?</span>
          <svg className="w-5 h-5 text-slate-500 transform transition-transform faq-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        <div className="faq-content hidden px-6 pb-4 text-slate-600">
          No. El acompañamiento completo de onboarding está incluido en todos los planes, desde Starter hasta Enterprise. Esto incluye la verificación de Meta, la integración con Siigo y la capacitación en vivo de tu equipo.
        </div>
      </div>
      <div className="faq-item border border-slate-200 rounded-xl overflow-hidden">
        <button className="faq-toggle w-full px-6 py-4 text-left flex items-center justify-between hover:bg-slate-50 transition-colors">
          <span className="font-semibold text-slate-900">¿Pierdo mi número de WhatsApp o mis conversaciones actuales?</span>
          <svg className="w-5 h-5 text-slate-500 transform transition-transform faq-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        <div className="faq-content hidden px-6 pb-4 text-slate-600">
          No pierdes tu número. Lo migramos a la API oficial de WhatsApp Business conservando tu identidad. Las conversaciones históricas de la app personal no se transfieren, pero tu equipo arranca con una bandeja centralizada profesional desde el primer minuto.
        </div>
      </div>
      <div className="faq-item border border-slate-200 rounded-xl overflow-hidden">
        <button className="faq-toggle w-full px-6 py-4 text-left flex items-center justify-between hover:bg-slate-50 transition-colors">
          <span className="font-semibold text-slate-900">¿Qué pasa si mi equipo no es técnico?</span>
          <svg className="w-5 h-5 text-slate-500 transform transition-transform faq-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        <div className="faq-content hidden px-6 pb-4 text-slate-600">
          No necesitas conocimientos técnicos. Tu especialista dedicado ejecuta toda la configuración y la capacitación está diseñada para equipos comerciales: si saben usar WhatsApp, saben usar ChatFlow.
        </div>
      </div>
      <div className="faq-item border border-slate-200 rounded-xl overflow-hidden">
        <button className="faq-toggle w-full px-6 py-4 text-left flex items-center justify-between hover:bg-slate-50 transition-colors">
          <span className="font-semibold text-slate-900">¿Ofrecen soporte después del lanzamiento?</span>
          <svg className="w-5 h-5 text-slate-500 transform transition-transform faq-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        <div className="faq-content hidden px-6 pb-4 text-slate-600">
          Sí. Durante los primeros 7 días tienes acompañamiento prioritario de tu especialista. Después, cuentas con soporte por chat en horario laboral colombiano, y los planes Growth Pro y Enterprise incluyen soporte extendido 24/7.
        </div>
      </div>
    </div>
    <div className="mt-12 bg-gradient-to-r from-emerald-600 to-emerald-500 rounded-2xl p-8 lg:p-10 text-center">
      <h3 className="font-heading text-2xl lg:text-3xl font-bold text-white mb-3">
        ¿Listo para activar tu WhatsApp empresarial?
      </h3>
      <p className="text-emerald-100 mb-6 max-w-xl mx-auto">
        Agenda tu sesión de kickoff hoy y empieza a vender con IA y facturación automática esta misma semana.
      </p>
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <button className="bg-white text-emerald-600 px-8 py-4 rounded-xl font-bold text-lg transition-all transform hover:scale-105 active:scale-95 shadow-lg">
          Comenzar Onboarding Gratis
        </button>
        <button className="border-2 border-white/40 hover:border-white text-white px-8 py-4 rounded-xl font-bold text-lg transition-all hover:bg-white/10">
          Agendar Llamada
        </button>
      </div>
    </div>
  </div>
</section>


    );
};

export default OnboardingInfoSectionCustomComponents6;