import React from 'react';

const IndexSectionCustomComponents2: React.FC = () => {
    return (
        <section className="relative bg-slate-900 text-white overflow-hidden">
  <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-900/20" />
  <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-emerald-500/10 to-transparent" />
  <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
    <div className="grid lg:grid-cols-12 gap-12 items-center">
      <div className="lg:col-span-6 space-y-8">
        <div className="inline-flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-4 py-2">
          <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
          <span className="text-emerald-400 text-sm font-medium">Integración Oficial Meta &amp; Siigo</span>
        </div>
        <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight tracking-tight">
          El CRM Nativo para <span className="text-emerald-400">WhatsApp</span> que automatiza tus ventas
        </h1>
        <p className="text-lg sm:text-xl text-slate-300 leading-relaxed max-w-2xl">
          Elimina la digitación manual. Responde a tus clientes en segundos con Copiloto de Inteligencia Artificial y genera facturas electrónicas de la DIAN directamente dentro del chat.
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <button className="bg-emerald-500 hover:bg-emerald-600 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all transform hover:scale-105 active:scale-95 shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2">
            Probar Gratis
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
          </button>
          <button className="border-2 border-slate-600 hover:border-emerald-500 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all hover:bg-emerald-500/10 flex items-center justify-center gap-2"><svg className="w-5 h-5 text-emerald-400" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" /></svg>
            Demo en Vivo
          </button>
        </div>
        <div className="pt-8 border-t border-slate-800">
          <p className="text-sm text-slate-400 mb-4">Integrado con las herramientas que ya usas:</p>
          <div className="flex flex-wrap items-center gap-6 opacity-70">
            <span className="text-slate-300 font-semibold text-sm">Meta WhatsApp</span>
            <span className="text-slate-300 font-semibold text-sm">Siigo</span>
            <span className="text-slate-300 font-semibold text-sm">Bold</span>
            <span className="text-slate-300 font-semibold text-sm">Wompi</span>
            <span className="text-slate-300 font-semibold text-sm">Bancolombia</span>
            <span className="text-slate-300 font-semibold text-sm">Nequi</span>
          </div>
        </div>
      </div>
      <div className="lg:col-span-6 relative">
        <div className="relative bg-slate-800 rounded-2xl border border-slate-700 shadow-2xl overflow-hidden">
          <div className="bg-slate-900 px-4 py-3 border-b border-slate-700 flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            <div className="w-3 h-3 rounded-full bg-yellow-500" />
            <div className="w-3 h-3 rounded-full bg-emerald-500" />
          </div>
          <div className="grid grid-cols-2 divide-x divide-slate-700">
            <div className="p-4 bg-slate-800/50">
              <div className="text-xs text-slate-400 mb-3 uppercase tracking-wider">WhatsApp Chat</div>
              <div className="space-y-3">
                <div className="bg-slate-700 rounded-lg p-3 text-sm text-slate-200 max-w-[80%]">
                  Hola, quiero cotizar 50 unidades del producto A
                </div>
                <div className="bg-emerald-600 rounded-lg p-3 text-sm text-white max-w-[80%] ml-auto">
                  ¡Claro! Generando cotización...
                </div>
                <div className="bg-emerald-600 rounded-lg p-3 text-sm text-white max-w-[80%] ml-auto flex items-center gap-2"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                  Factura #001 generada
                </div>
              </div>
            </div>
            <div className="p-4 bg-slate-900">
              <div className="text-xs text-slate-400 mb-3 uppercase tracking-wider">Siigo Automático</div>
              <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-emerald-400 text-sm font-semibold">Factura Electrónica</span>
                  <span className="bg-emerald-500/20 text-emerald-400 text-xs px-2 py-1 rounded">DIAN</span>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between text-slate-300">
                    <span>Producto A x50</span>
                    <span>$2.500.000</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>IVA (19%)</span>
                    <span>$475.000</span>
                  </div>
                  <div className="border-t border-slate-700 pt-2 flex justify-between text-white font-bold">
                    <span>Total</span>
                    <span>$2.975.000</span>
                  </div>
                </div>
                <button className="w-full mt-4 bg-emerald-500 text-white py-2 rounded-lg text-sm font-semibold">
                  Enviar Link de Pago
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute -bottom-6 -left-6 bg-white text-slate-900 rounded-xl p-4 shadow-xl border border-slate-200 hidden lg:block">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center">
              <svg className="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-900">1.2s</div>
              <div className="text-xs text-slate-500">Tiempo de respuesta IA</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


    );
};

export default IndexSectionCustomComponents2;