import React from 'react';

const MessagesInboxSectionCustomComponents3: React.FC = () => {
    return (
        <footer className="bg-slate-900 text-white py-8 border-t border-slate-800">
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div className="flex flex-col md:flex-row justify-between items-center gap-4">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
          <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
          </svg>
        </div>
        <span className="font-heading font-bold text-lg">Verifika</span>
      </div>
      <p className="text-slate-500 text-sm">© 2026 Verifika CRM. Todos los derechos reservados.</p>
      <div className="flex gap-4">
        <a href="#" className="text-slate-400 hover:text-white transition-colors text-sm">Términos</a>
        <a href="#" className="text-slate-400 hover:text-white transition-colors text-sm">Privacidad</a>
        <a href="#" className="text-slate-400 hover:text-white transition-colors text-sm">Soporte</a>
      </div>
    </div>
  </div>
</footer>


    );
};

export default MessagesInboxSectionCustomComponents3;