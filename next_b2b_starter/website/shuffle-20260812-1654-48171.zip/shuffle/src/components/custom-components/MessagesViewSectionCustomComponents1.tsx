import React from 'react';

const MessagesViewSectionCustomComponents1: React.FC = () => {
    return (
        <section className="mensajes-view bg-slate-50 min-h-screen">
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    {/* Header */}
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
      <div>
        <h1 className="font-heading text-2xl sm:text-3xl font-bold text-slate-900">Mensajes</h1>
        <p className="text-slate-600 mt-1">Gestiona tus conversaciones de WhatsApp en un solo lugar</p>
      </div>
      <div className="flex items-center gap-3">
        <button className="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200 rounded-lg text-slate-700 font-medium hover:bg-slate-50 transition-colors">
          <span className="w-2 h-2 bg-emerald-500 rounded-full" />
          Conectado
        </button>
        <button className="inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-500 text-white rounded-lg font-medium hover:bg-emerald-600 transition-colors">
          <span className="text-lg leading-none">+</span>
          Nueva campaña
        </button>
      </div>
    </div>
    {/* Stats Cards */}
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      <div className="bg-white rounded-xl p-5 border border-slate-200">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm text-slate-500">Conversaciones hoy</span>
          <div className="w-8 h-8 bg-emerald-50 rounded-lg flex items-center justify-center">
            <span className="text-emerald-600 text-lg">💬</span>
          </div>
        </div>
        <div className="text-2xl font-bold text-slate-900">247</div>
        <div className="text-xs text-emerald-600 mt-1 flex items-center gap-1">
          <span>↑</span>
          <span>12% vs ayer</span>
        </div>
      </div>
      <div className="bg-white rounded-xl p-5 border border-slate-200">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm text-slate-500">Por responder</span>
          <div className="w-8 h-8 bg-amber-50 rounded-lg flex items-center justify-center">
            <span className="text-amber-600 text-lg">⏰</span>
          </div>
        </div>
        <div className="text-2xl font-bold text-slate-900">18</div>
        <div className="text-xs text-amber-600 mt-1 flex items-center gap-1">
          <span>⚠</span>
          <span>5 urgentes</span>
        </div>
      </div>
      <div className="bg-white rounded-xl p-5 border border-slate-200">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm text-slate-500">Tasa de respuesta</span>
          <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center">
            <span className="text-blue-600 text-lg">📊</span>
          </div>
        </div>
        <div className="text-2xl font-bold text-slate-900">94%</div>
        <div className="text-xs text-emerald-600 mt-1 flex items-center gap-1">
          <span>↑</span>
          <span>3% este mes</span>
        </div>
      </div>
      <div className="bg-white rounded-xl p-5 border border-slate-200">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm text-slate-500">Tiempo promedio</span>
          <div className="w-8 h-8 bg-purple-50 rounded-lg flex items-center justify-center">
            <span className="text-purple-600 text-lg">⚡</span>
          </div>
        </div>
        <div className="text-2xl font-bold text-slate-900">4.2m</div>
        <div className="text-xs text-emerald-600 mt-1 flex items-center gap-1">
          <span>↓</span>
          <span>Mejorando</span>
        </div>
      </div>
    </div>
    {/* Main Content */}
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
      {/* Toolbar */}
      <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">🔍</span>
          <input type="text" placeholder="Buscar conversaciones..." className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent" />
        </div>
        <div className="flex items-center gap-2">
          <select className="px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500">
            <option>Todos los estados</option>
            <option>Por responder</option>
            <option>Resueltos</option>
            <option>Archivados</option>
          </select>
          <select className="px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500">
            <option>Todos los agentes</option>
            <option>Sin asignar</option>
            <option>María G.</option>
            <option>Carlos R.</option>
            <option>Ana L.</option>
          </select>
          <button className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-100 transition-colors">🔄</button>
        </div>
      </div>
      {/* Conversations List */}
      <div className="divide-y divide-slate-100">
        {/* Conversation Item 1 */}
        <div className="conversation-item p-4 hover:bg-slate-50 transition-colors cursor-pointer group">
          <div className="flex items-start gap-4">
            <div className="relative flex-shrink-0">
              <img src="https://placehold.co/48x48/10b981/ffffff?text=MG" alt="Cliente" className="w-12 h-12 rounded-full object-cover" />
              <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 border-2 border-white rounded-full" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <h3 className="font-semibold text-slate-900 truncate">María González</h3>
                <span className="text-xs text-slate-400 flex-shrink-0">10:42 AM</span>
              </div>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-emerald-100 text-emerald-700">Cliente</span>
                <span className="text-xs text-slate-500">Pedido #4821</span>
              </div>
              <p className="text-sm text-slate-600 mt-1.5 truncate group-hover:text-slate-900 transition-colors">Hola, quería saber si ya está listo mi pedido de ayer. Es urgente porque lo necesito para...</p>
            </div>
            <div className="flex flex-col items-end gap-2 flex-shrink-0">
              <span className="w-6 h-6 bg-emerald-500 text-white text-xs font-bold rounded-full flex items-center justify-center">2</span>
              <span className="text-xs text-amber-600 font-medium">Por responder</span>
            </div>
          </div>
        </div>
        {/* Conversation Item 2 */}
        <div className="conversation-item p-4 hover:bg-slate-50 transition-colors cursor-pointer group">
          <div className="flex items-start gap-4">
            <div className="relative flex-shrink-0">
              <img src="https://placehold.co/48x48/6366f1/ffffff?text=CR" alt="Cliente" className="w-12 h-12 rounded-full object-cover" />
              <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-gray-400 border-2 border-white rounded-full" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <h3 className="font-semibold text-slate-900 truncate">Carlos Rodríguez</h3>
                <span className="text-xs text-slate-400 flex-shrink-0">Ayer</span>
              </div>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-700">Prospecto</span>
                <span className="text-xs text-slate-500">Cotización</span>
              </div>
              <p className="text-sm text-slate-600 mt-1.5 truncate group-hover:text-slate-900 transition-colors">Perfecto, me parece bien el precio. ¿Me puedes enviar la factura por favor? Mi NIT es...</p>
            </div>
            <div className="flex flex-col items-end gap-2 flex-shrink-0">
              <span className="w-6 h-6 bg-emerald-500 text-white text-xs font-bold rounded-full flex items-center justify-center">1</span>
              <span className="text-xs text-slate-500">Pendiente</span>
            </div>
          </div>
        </div>
        {/* Conversation Item 3 */}
        <div className="conversation-item p-4 hover:bg-slate-50 transition-colors cursor-pointer group bg-emerald-50/30">
          <div className="flex items-start gap-4">
            <div className="relative flex-shrink-0">
              <img src="https://placehold.co/48x48/f59e0b/ffffff?text=AL" alt="Cliente" className="w-12 h-12 rounded-full object-cover" />
              <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 border-2 border-white rounded-full" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <h3 className="font-semibold text-slate-900 truncate">Ana Lucía Martínez</h3>
                <span className="text-xs text-emerald-600 font-medium flex-shrink-0">Ahora</span>
              </div>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-purple-100 text-purple-700">VIP</span>
                <span className="text-xs text-slate-500">Soporte técnico</span>
              </div>
              <p className="text-sm text-slate-600 mt-1.5 truncate group-hover:text-slate-900 transition-colors">
                <span className="text-emerald-600 font-medium">Escribiendo...</span>
              </p>
            </div>
            <div className="flex flex-col items-end gap-2 flex-shrink-0">
              <span className="px-2 py-1 bg-emerald-500 text-white text-xs font-medium rounded-full">Activo</span>
            </div>
          </div>
        </div>
        {/* Conversation Item 4 */}
        <div className="conversation-item p-4 hover:bg-slate-50 transition-colors cursor-pointer group">
          <div className="flex items-start gap-4">
            <div className="relative flex-shrink-0">
              <img src="https://placehold.co/48x48/ef4444/ffffff?text=JP" alt="Cliente" className="w-12 h-12 rounded-full object-cover" />
              <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-gray-400 border-2 border-white rounded-full" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <h3 className="font-semibold text-slate-900 truncate">Juan Pablo Herrera</h3>
                <span className="text-xs text-slate-400 flex-shrink-0">Lun</span>
              </div>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-emerald-100 text-emerald-700">Cliente</span>
                <span className="text-xs text-slate-500">Facturación</span>
              </div>
              <p className="text-sm text-slate-600 mt-1.5 truncate group-hover:text-slate-900 transition-colors">Ya recibí la factura, muchas gracias. Quedo atento para la próxima entrega.</p>
            </div>
            <div className="flex flex-col items-end gap-2 flex-shrink-0">
              <span className="text-xs text-emerald-600 font-medium">Resuelto</span>
            </div>
          </div>
        </div>
        {/* Conversation Item 5 */}
        <div className="conversation-item p-4 hover:bg-slate-50 transition-colors cursor-pointer group">
          <div className="flex items-start gap-4">
            <div className="relative flex-shrink-0">
              <img src="https://placehold.co/48x48/8b5cf6/ffffff?text=DT" alt="Cliente" className="w-12 h-12 rounded-full object-cover" />
              <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-gray-400 border-2 border-white rounded-full" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <h3 className="font-semibold text-slate-900 truncate">Distribuidora Tropical SAS</h3>
                <span className="text-xs text-slate-400 flex-shrink-0">Dom</span>
              </div>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-700">Mayorista</span>
                <span className="text-xs text-slate-500">Pedido recurrente</span>
              </div>
              <p className="text-sm text-slate-600 mt-1.5 truncate group-hover:text-slate-900 transition-colors">Adjunto el pedido de esta semana. Son 50 unidades del producto A y 30 del producto B...</p>
            </div>
            <div className="flex flex-col items-end gap-2 flex-shrink-0">
              <span className="w-6 h-6 bg-emerald-500 text-white text-xs font-bold rounded-full flex items-center justify-center">3</span>
              <span className="text-xs text-amber-600 font-medium">Por responder</span>
            </div>
          </div>
        </div>
        {/* Conversation Item 6 */}
        <div className="conversation-item p-4 hover:bg-slate-50 transition-colors cursor-pointer group">
          <div className="flex items-start gap-4">
            <div className="relative flex-shrink-0">
              <img src="https://placehold.co/48x48/ec4899/ffffff?text=SF" alt="Cliente" className="w-12 h-12 rounded-full object-cover" />
              <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-gray-400 border-2 border-white rounded-full" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <h3 className="font-semibold text-slate-900 truncate">Sofía Fernández</h3>
                <span className="text-xs text-slate-400 flex-shrink-0">Vie</span>
              </div>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-700">Nuevo</span>
                <span className="text-xs text-slate-500">Primera compra</span>
              </div>
              <p className="text-sm text-slate-600 mt-1.5 truncate group-hover:text-slate-900 transition-colors">Me interesa mucho su producto. ¿Tienen envío a Medellín? ¿Cuánto tarda?</p>
            </div>
            <div className="flex flex-col items-end gap-2 flex-shrink-0">
              <span className="text-xs text-slate-500">Archivado</span>
            </div>
          </div>
        </div>
      </div>
      {/* Pagination */}
      <div className="p-4 border-t border-slate-200 flex items-center justify-between">
        <p className="text-sm text-slate-500">Mostrando 6 de 247 conversaciones</p>
        <div className="flex items-center gap-2">
          <button className="px-3 py-2 text-sm text-slate-500 hover:text-slate-700 disabled:opacity-50" disabled>Anterior</button>
          <button className="px-3 py-2 text-sm bg-emerald-500 text-white rounded-lg font-medium">1</button>
          <button className="px-3 py-2 text-sm text-slate-600 hover:bg-slate-100 rounded-lg">2</button>
          <button className="px-3 py-2 text-sm text-slate-600 hover:bg-slate-100 rounded-lg">3</button>
          <span className="text-slate-400">...</span>
          <button className="px-3 py-2 text-sm text-slate-600 hover:bg-slate-100 rounded-lg">42</button>
          <button className="px-3 py-2 text-sm text-slate-600 hover:text-slate-900">Siguiente</button>
        </div>
      </div>
    </div>
    {/* Quick Actions */}
    <div className="mt-8 grid sm:grid-cols-3 gap-4">
      <div className="bg-white rounded-xl p-5 border border-slate-200 hover:border-emerald-300 transition-colors cursor-pointer group">
        <div className="w-10 h-10 bg-emerald-50 rounded-lg flex items-center justify-center mb-3 group-hover:bg-emerald-100 transition-colors">
          <span className="text-emerald-600 text-lg">🤖</span>
        </div>
        <h3 className="font-semibold text-slate-900 mb-1">Configurar Auto-Respuestas</h3>
        <p className="text-sm text-slate-500">Automatiza respuestas frecuentes con IA</p>
      </div>
      <div className="bg-white rounded-xl p-5 border border-slate-200 hover:border-emerald-300 transition-colors cursor-pointer group">
        <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center mb-3 group-hover:bg-blue-100 transition-colors">
          <span className="text-blue-600 text-lg">📋</span>
        </div>
        <h3 className="font-semibold text-slate-900 mb-1">Plantillas de Mensajes</h3>
        <p className="text-sm text-slate-500">Crea y gestiona plantillas aprobadas por Meta</p>
      </div>
      <div className="bg-white rounded-xl p-5 border border-slate-200 hover:border-emerald-300 transition-colors cursor-pointer group">
        <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center mb-3 group-hover:bg-purple-100 transition-colors">
          <span className="text-purple-600 text-lg">📈</span>
        </div>
        <h3 className="font-semibold text-slate-900 mb-1">Reportes de Conversación</h3>
        <p className="text-sm text-slate-500">Analiza métricas de atención al cliente</p>
      </div>
    </div>
  </div>
</section>


    );
};

export default MessagesViewSectionCustomComponents1;