import React from 'react';

const SignInSectionCustomComponents2: React.FC = () => {
    return (
        <section className="relative bg-slate-900 text-white overflow-hidden min-h-screen flex items-center">
  <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-900/20" />
  <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-emerald-500/10 to-transparent" />
  <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 w-full">
    <div className="grid lg:grid-cols-12 gap-12 items-center">
      <div className="lg:col-span-5 space-y-8">
        <div className="inline-flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-4 py-2">
          <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
          <span className="text-emerald-400 text-sm font-medium">Acceso Seguro Empresarial</span>
        </div>
        <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight tracking-tight">
          Bienvenido a <span className="text-emerald-400">ParceFlow</span>
        </h1>
        <p className="text-lg sm:text-xl text-slate-300 leading-relaxed">
          Accede a tu panel de control y comienza a automatizar tus ventas por WhatsApp con inteligencia artificial.
        </p>
        <div className="space-y-4 pt-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-emerald-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
              <svg className="w-5 h-5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            </div>
            <div>
              <h3 className="font-semibold text-white mb-1">Datos Protegidos</h3>
              <p className="text-sm text-slate-400">Cumplimos con la Ley 1581 de Habeas Data en Colombia</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-emerald-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
              <svg className="w-5 h-5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <div>
              <h3 className="font-semibold text-white mb-1">Configuración en 60 segundos</h3>
              <p className="text-sm text-slate-400">Conecta tu WhatsApp Business y Siigo al instante</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-emerald-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
              <svg className="w-5 h-5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
            </div>
            <div>
              <h3 className="font-semibold text-white mb-1">Soporte 24/7</h3>
              <p className="text-sm text-slate-400">Equipo dedicado para empresas en Colombia y LATAM</p>
            </div>
          </div>
        </div>
      </div>
      <div className="lg:col-span-7">
        <div className="bg-slate-800 rounded-2xl border border-slate-700 shadow-2xl overflow-hidden">
          <div className="bg-slate-900 px-6 py-4 border-b border-slate-700">
            <div className="flex gap-2">
              <button className="auth-tab flex-1 py-3 px-4 rounded-lg font-semibold text-sm transition-all bg-emerald-500 text-white" data-tab="signin">
                Iniciar Sesión
              </button>
              <button className="auth-tab flex-1 py-3 px-4 rounded-lg font-semibold text-sm transition-all text-slate-400 hover:text-white" data-tab="signup">
                Crear Cuenta
              </button>
            </div>
          </div>
          <div className="p-8">
            <div className="auth-form" data-form="signin">
              <div className="mb-6">
                <h2 className="font-heading text-2xl font-bold mb-2">Accede a tu cuenta</h2>
                <p className="text-slate-400 text-sm">Ingresa tus credenciales para continuar</p>
              </div>
              <form className="space-y-5">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Correo Electrónico</label>
                  <input type="email" placeholder="tu@empresa.com" className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Contraseña</label>
                  <input type="password" placeholder="••••••••" className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all" />
                </div>
                <div className="flex items-center justify-between text-sm">
                  <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                    <input type="checkbox" className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-emerald-500 focus:ring-emerald-500/20" />
                    <span>Recordarme</span>
                  </label>
                  <a href="#" className="text-emerald-400 hover:text-emerald-300 transition-colors">¿Olvidaste tu contraseña?</a>
                </div>
                <button type="submit" className="w-full bg-emerald-500 hover:bg-emerald-600 text-white py-3.5 rounded-lg font-bold transition-all transform hover:scale-105 active:scale-95 shadow-lg shadow-emerald-500/25">
                  Iniciar Sesión
                </button>
                <div className="relative my-6">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-slate-700" />
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-4 bg-slate-800 text-slate-400">O continúa con</span>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <button type="button" className="flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-700 border border-slate-700 text-white py-3 rounded-lg font-semibold transition-all"><svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" /><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" /><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" /><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" /></svg>
                    Google
                  </button>
                  <button type="button" className="flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-700 border border-slate-700 text-white py-3 rounded-lg font-semibold transition-all"><svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z" /></svg>
                    GitHub
                  </button>
                </div>
              </form>
            </div>
            <div className="auth-form hidden" data-form="signup">
              <div className="mb-6">
                <h2 className="font-heading text-2xl font-bold mb-2">Crea tu cuenta gratis</h2>
                <p className="text-slate-400 text-sm">Comienza a automatizar tus ventas en minutos</p>
              </div>
              <form className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Nombre</label>
                    <input type="text" placeholder="Juan" className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">Apellido</label>
                    <input type="text" placeholder="Pérez" className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Correo Electrónico Empresarial</label>
                  <input type="email" placeholder="tu@empresa.com" className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Nombre de la Empresa</label>
                  <input type="text" placeholder="Mi Empresa S.A.S." className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">Contraseña</label>
                  <input type="password" placeholder="Mínimo 8 caracteres" className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all" />
                </div>
                <div className="flex items-start gap-2 text-sm">
                  <input type="checkbox" className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-emerald-500 focus:ring-emerald-500/20 mt-0.5" />
                  <label className="text-slate-300">
                    Acepto los <a href="#" className="text-emerald-400 hover:text-emerald-300">Términos de Servicio</a> y la <a href="#" className="text-emerald-400 hover:text-emerald-300">Política de Privacidad</a>
                  </label>
                </div>
                <button type="submit" className="w-full bg-emerald-500 hover:bg-emerald-600 text-white py-3.5 rounded-lg font-bold transition-all transform hover:scale-105 active:scale-95 shadow-lg shadow-emerald-500/25">
                  Crear Cuenta Gratis
                </button>
                <p className="text-center text-sm text-slate-400">
                  Sin tarjeta de crédito • Configuración en 60 segundos
                </p>
              </form>
            </div>
          </div>
        </div>
        <div className="mt-6 bg-slate-800/50 backdrop-blur rounded-xl p-4 border border-slate-700">
          <div className="flex items-center gap-3 text-sm">
            <div className="w-10 h-10 bg-emerald-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
              <svg className="w-5 h-5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            </div>
            <div>
              <p className="text-white font-semibold">Conexión Segura SSL</p>
              <p className="text-slate-400 text-xs">Tus datos están protegidos con encriptación de nivel bancario</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


    );
};

export default SignInSectionCustomComponents2;