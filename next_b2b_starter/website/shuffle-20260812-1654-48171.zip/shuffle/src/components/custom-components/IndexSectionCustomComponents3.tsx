import React from 'react';

const IndexSectionCustomComponents3: React.FC = () => {
    return (
        <section className="py-20 lg:py-28 bg-white">
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div className="text-center max-w-3xl mx-auto mb-16">
      <h2 className="font-heading text-3xl sm:text-4xl font-bold text-slate-900 mb-4">
        Deja de perder ventas por procesos manuales
      </h2>
      <p className="text-lg text-slate-600">
        La diferencia entre cerrar una venta y perderla está en la velocidad de respuesta.
      </p>
    </div>
    <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
      <div className="bg-slate-50 rounded-2xl p-8 border border-slate-200">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
            <svg className="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </div>
          <h3 className="font-heading text-xl font-bold text-slate-900">El Proceso Tradicional</h3>
        </div>
        <ul className="space-y-4">
          <li className="flex items-start gap-3 text-slate-600">
            <svg className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span>Vendedores digitando manualmente cotizaciones en Siigo</span>
          </li>
          <li className="flex items-start gap-3 text-slate-600">
            <svg className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span>Clientes esperando 20 minutos por una respuesta</span>
          </li>
          <li className="flex items-start gap-3 text-slate-600">
            <svg className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span>Asesores usando cuentas personales sin control empresarial</span>
          </li>
          <li className="flex items-start gap-3 text-slate-600">
            <svg className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span>Facturas y links de pago enviados manualmente</span>
          </li>
        </ul>
      </div>
      <div className="bg-emerald-50 rounded-2xl p-8 border border-emerald-200 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full -translate-y-1/2 translate-x-1/2" />
        <div className="flex items-center gap-3 mb-6 relative">
          <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center">
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h3 className="font-heading text-xl font-bold text-slate-900">Con ChatFlow IA</h3>
        </div>
        <ul className="space-y-4 relative">
          <li className="flex items-start gap-3 text-slate-700">
            <svg className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            <span>Copiloto de IA extrae productos y precios en 1 segundo</span>
          </li>
          <li className="flex items-start gap-3 text-slate-700">
            <svg className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            <span>Respuestas instantáneas y sugerencias en un clic</span>
          </li>
          <li className="flex items-start gap-3 text-slate-700">
            <svg className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            <span>Bandeja multi-agente centralizada para toda la empresa</span>
          </li>
          <li className="flex items-start gap-3 text-slate-700">
            <svg className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            <span>Facturación DIAN y cobros PSE/Nequi en tiempo real</span>
          </li>
        </ul>
      </div>
    </div>
  </div>
</section>


    );
};

export default IndexSectionCustomComponents3;