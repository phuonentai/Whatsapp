import React from 'react';

const MessagesInboxSectionCustomComponents1: React.FC = () => {
    return (
        <nav className="bg-slate-900 text-white border-b border-slate-800">
  <div className="max-w-full mx-auto px-4 sm:px-6 lg:px-8">
    <div className="flex items-center justify-between h-16">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
          <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
          </svg>
        </div>
        <span className="font-heading font-bold text-xl tracking-tight">Verifika</span>
      </div>
      <div className="hidden md:flex items-center gap-6">
        <a href="/dashboard" className="text-sm text-slate-300 hover:text-white transition-colors">Dashboard</a>
        <a href="/messages-inbox" className="text-sm text-white font-medium border-b-2 border-emerald-500 pb-0.5">Bandeja</a>
        <a href="/ai-settings-view" className="text-sm text-slate-300 hover:text-white transition-colors">Configuración IA</a>
        <div className="h-6 w-px bg-slate-700" />
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-slate-700 rounded-full flex items-center justify-center text-sm font-medium">MC</div>
        </div>
      </div>
      <button className="md:hidden mobile-menu-btn p-2">
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>
    </div>
  </div>
  <div className="mobile-menu hidden md:hidden bg-slate-800 border-t border-slate-700">
    <div className="px-4 py-4 space-y-3">
      <a href="/dashboard" className="block text-slate-300 hover:text-white py-2">Dashboard</a>
      <a href="/messages-inbox" className="block text-white font-medium py-2">Bandeja</a>
      <a href="/ai-settings-view" className="block text-slate-300 hover:text-white py-2">Configuración IA</a>
    </div>
  </div>
</nav>


    );
};

export default MessagesInboxSectionCustomComponents1;