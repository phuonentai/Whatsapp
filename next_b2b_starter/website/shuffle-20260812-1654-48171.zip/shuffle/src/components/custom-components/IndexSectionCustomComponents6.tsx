import React from 'react';

const IndexSectionCustomComponents6: React.FC = () => {
    return (
        <section id="faq" className="py-20 lg:py-28 bg-white">
  <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
    <div className="text-center mb-12">
      <h2 className="font-heading text-3xl sm:text-4xl font-bold text-slate-900 mb-4">
        Preguntas Frecuentes
      </h2>
      <p className="text-lg text-slate-600">
        Resolvemos tus dudas sobre la integración con Siigo y WhatsApp.
      </p>
    </div>
    <div className="space-y-4">
      <div className="faq-item border border-slate-200 rounded-xl overflow-hidden">
        <button className="faq-toggle w-full px-6 py-4 text-left flex items-center justify-between hover:bg-slate-50 transition-colors">
          <span className="font-semibold text-slate-900">¿Reemplaza esto a mi cuenta actual de Siigo?</span>
          <svg className="w-5 h-5 text-slate-500 transform transition-transform faq-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        <div className="faq-content hidden px-6 pb-4 text-slate-600">
          No, la potencia. Nos conectamos por API para que no tengas que digitar dos veces. Siigo sigue siendo tu sistema contable principal, nosotros automatizamos la entrada de datos desde WhatsApp.
        </div>
      </div>
      <div className="faq-item border border-slate-200 rounded-xl overflow-hidden">
        <button className="faq-toggle w-full px-6 py-4 text-left flex items-center justify-between hover:bg-slate-50 transition-colors">
          <span className="font-semibold text-slate-900">¿Es legal según la Ley 1581 de Habeas Data en Colombia?</span>
          <svg className="w-5 h-5 text-slate-500 transform transition-transform faq-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        <div className="faq-content hidden px-6 pb-4 text-slate-600">
          Sí, todos los datos están encriptados y cumplen estrictamente con la normativa colombiana de protección de datos. Somos compliant con la Ley 1581 y el RGPD.
        </div>
      </div>
      <div className="faq-item border border-slate-200 rounded-xl overflow-hidden">
        <button className="faq-toggle w-full px-6 py-4 text-left flex items-center justify-between hover:bg-slate-50 transition-colors">
          <span className="font-semibold text-slate-900">¿Debo pagar costos adicionales a Meta?</span>
          <svg className="w-5 h-5 text-slate-500 transform transition-transform faq-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        <div className="faq-content hidden px-6 pb-4 text-slate-600">
          No para mensajes entrantes dentro de las 24 horas. Solo pagas por conversaciones iniciadas por la empresa fuera de la ventana de 24h según las tarifas estándar de Meta.
        </div>
      </div>
      <div className="faq-item border border-slate-200 rounded-xl overflow-hidden">
        <button className="faq-toggle w-full px-6 py-4 text-left flex items-center justify-between hover:bg-slate-50 transition-colors">
          <span className="font-semibold text-slate-900">¿Funciona con mi número actual de WhatsApp?</span>
          <svg className="w-5 h-5 text-slate-500 transform transition-transform faq-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        <div className="faq-content hidden px-6 pb-4 text-slate-600">
          Sí, puedes migrar tu número actual a la API oficial de WhatsApp Business. Te guiamos en todo el proceso de verificación con Meta.
        </div>
      </div>
    </div>
  </div>
</section>


    );
};

export default IndexSectionCustomComponents6;