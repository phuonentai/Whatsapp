import React from 'react';

const AiSettingsViewSectionCustomComponents3: React.FC = () => {
    return (
        <section className="bg-slate-50 py-8">
  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div className="grid lg:grid-cols-12 gap-8">
      <div className="lg:col-span-8 space-y-6">
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center">
              <svg className="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
              </svg>
            </div>
            <div>
              <h2 className="font-heading text-lg font-bold text-slate-900">Comportamiento del Asistente</h2>
              <p className="text-sm text-slate-500">Define cómo responde la IA a tus clientes</p>
            </div>
          </div>
          <div className="space-y-6">
            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Modo de operación</label>
                <div className="relative">
                  <select className="w-full appearance-none bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 pr-10 text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all">
                    <option value="copilot">🤝 Copiloto — Sugiere, tú apruebas</option>
                    <option value="autopilot">🚀 Autopiloto — Envía automáticamente</option>
                  </select>
                  <svg className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
                <p className="mt-2 text-xs text-slate-500">El modo Copiloto requiere aprobación humana para cada mensaje</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Tono de comunicación</label>
                <div className="relative">
                  <select className="w-full appearance-none bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 pr-10 text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all">
                    <option value="formal">Formal — Profesional y respetuoso</option>
                    <option value="casual">Casual — Amigable y cercano</option>
                    <option value="neutral">Neutral — Equilibrado</option>
                  </select>
                  <svg className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Voz de marca</label>
              <textarea rows={3} placeholder="Describe cómo debe sonar tu marca. Ej: 'Somos expertos en tecnología, hablamos con claridad y siempre ofrecemos soluciones concretas...'" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all resize-none" defaultValue={""} />
              <p className="mt-2 text-xs text-slate-500">La IA usará estas instrucciones para mantener consistencia en todas las respuestas</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center">
              <svg className="w-5 h-5 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h2 className="font-heading text-lg font-bold text-slate-900">Ventana de Autopiloto</h2>
              <p className="text-sm text-slate-500">Horarios en que la IA puede enviar mensajes automáticamente</p>
            </div>
          </div>
          <div className="grid sm:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Hora de inicio</label>
              <input type="time" defaultValue="08:00" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Hora de fin</label>
              <input type="time" defaultValue="20:00" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Zona horaria</label>
              <div className="relative">
                <select className="w-full appearance-none bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 pr-10 text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all">
                  <option>America/Bogota (GMT-5)</option>
                  <option>America/Mexico_City (GMT-6)</option>
                  <option>America/Lima (GMT-5)</option>
                </select>
                <svg className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </div>
          </div>
          <div className="mt-4 flex items-start gap-3 bg-amber-50 border border-amber-200 rounded-xl p-4">
            <svg className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <div>
              <p className="text-sm font-medium text-amber-800">Fuera de horario</p>
              <p className="text-xs text-amber-700 mt-0.5">Fuera de esta ventana, la IA operará en modo Copiloto (requiere aprobación humana)</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
              <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            </div>
            <div>
              <h2 className="font-heading text-lg font-bold text-slate-900">Guardarraíles de Seguridad</h2>
              <p className="text-sm text-slate-500">Límites y reglas que la IA nunca debe cruzar</p>
            </div>
          </div>
          <div className="space-y-6">
            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Descuento máximo permitido</label>
                <div className="relative">
                  <input type="number" defaultValue={10} min={0} max={100} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 pr-12 text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all" />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 font-medium">%</span>
                </div>
                <p className="mt-2 text-xs text-slate-500">La IA nunca ofrecerá descuentos mayores a este porcentaje</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Límite diario de mensajes</label>
                <div className="relative">
                  <input type="number" defaultValue={200} min={0} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all" />
                </div>
                <p className="mt-2 text-xs text-slate-500">0 = sin límite. Protege contra comportamiento inesperado</p>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Términos prohibidos</label>
              <div className="flex flex-wrap gap-2 p-3 bg-slate-50 border border-slate-200 rounded-xl min-h-[48px]">
                <span className="inline-flex items-center gap-1 bg-red-100 text-red-700 text-sm font-medium px-3 py-1 rounded-lg">
                  competencia
                  <button className="hover:text-red-900 transition-colors"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
                </span>
                <span className="inline-flex items-center gap-1 bg-red-100 text-red-700 text-sm font-medium px-3 py-1 rounded-lg">
                  gratis
                  <button className="hover:text-red-900 transition-colors"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
                </span>
                <input type="text" placeholder="+ Agregar término" className="flex-1 min-w-[120px] bg-transparent border-none text-sm text-slate-900 placeholder-slate-400 focus:outline-none" />
              </div>
              <p className="mt-2 text-xs text-slate-500">La IA nunca usará estas palabras en sus respuestas</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Términos de escalación</label>
              <div className="flex flex-wrap gap-2 p-3 bg-slate-50 border border-slate-200 rounded-xl min-h-[48px]">
                <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-700 text-sm font-medium px-3 py-1 rounded-lg">
                  abogado
                  <button className="hover:text-amber-900 transition-colors"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
                </span>
                <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-700 text-sm font-medium px-3 py-1 rounded-lg">
                  demanda
                  <button className="hover:text-amber-900 transition-colors"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
                </span>
                <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-700 text-sm font-medium px-3 py-1 rounded-lg">
                  superintendencia
                  <button className="hover:text-amber-900 transition-colors"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
                </span>
                <input type="text" placeholder="+ Agregar término" className="flex-1 min-w-[120px] bg-transparent border-none text-sm text-slate-900 placeholder-slate-400 focus:outline-none" />
              </div>
              <p className="mt-2 text-xs text-slate-500">Si el cliente menciona estos términos, la conversación se escala a un humano</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center">
              <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h2 className="font-heading text-lg font-bold text-slate-900">Consentimiento y Cumplimiento</h2>
              <p className="text-sm text-slate-500">Configuración de Ley 1581 de Habeas Data</p>
            </div>
          </div>
          <div className="space-y-6">
            <div className="flex items-start justify-between gap-4 p-4 bg-slate-50 rounded-xl">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-slate-900">Requerir consentimiento</span>
                  <span className="bg-purple-100 text-purple-700 text-xs font-semibold px-2 py-0.5 rounded">Ley 1581</span>
                </div>
                <p className="text-sm text-slate-500 mt-1">Las respuestas automáticas solo se envían a contactos que han otorgado consentimiento explícito</p>
              </div>
              <button className="relative w-12 h-7 bg-emerald-500 rounded-full transition-colors consent-toggle" aria-pressed="true">
                <span className="absolute top-1 left-6 w-5 h-5 bg-white rounded-full shadow-sm transition-transform" />
              </button>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Plantilla de consentimiento</label>
              <textarea rows={3} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all resize-none" defaultValue={"Autorizo el tratamiento de mis datos personales conforme a la Política de Privacidad de {{empresa}} y la Ley 1581 de 2012."} />
              <p className="mt-2 text-xs text-slate-500">Usa {'{'}{'{'}empresa{'}'}{'}'} para insertar el nombre de tu negocio automáticamente</p>
            </div>
            <div className="flex items-start gap-3 bg-purple-50 border border-purple-200 rounded-xl p-4">
              <svg className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <div>
                <p className="text-sm font-medium text-purple-800">Contactos sin consentimiento</p>
                <p className="text-xs text-purple-700 mt-0.5">El contexto de estos contactos se limitará a información estructural. No se procesarán datos personales adicionales.</p>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl border-2 border-red-200 p-6">
          <button className="w-full flex items-center justify-between danger-zone-toggle">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center">
                <svg className="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <div className="text-left">
                <h2 className="font-heading text-lg font-bold text-red-900">Zona de Peligro</h2>
                <p className="text-sm text-red-600">Acciones destructivas e irreversibles</p>
              </div>
            </div>
            <svg className="w-5 h-5 text-red-400 transition-transform danger-zone-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          <div className="danger-zone-content hidden mt-6 pt-6 border-t border-red-200">
            <div className="bg-red-50 rounded-xl p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-red-600 rounded-xl flex items-center justify-center flex-shrink-0">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                  </svg>
                </div>
                <div className="flex-1">
                  <h3 className="font-heading font-bold text-red-900">Kill Switch — Desactivar Asistente</h3>
                  <p className="text-sm text-red-700 mt-1">Detiene inmediatamente todos los envíos automáticos, incluso aquellos que ya fueron aprobados por un humano. Esta es una medida de emergencia.</p>
                  <div className="mt-4 space-y-3">
                    <div>
                      <label className="block text-sm font-medium text-red-800 mb-2">Escribe DESACTIVAR para confirmar</label>
                      <input type="text" placeholder="DESACTIVAR" className="w-full max-w-xs bg-white border-2 border-red-300 rounded-xl px-4 py-3 text-red-900 font-mono font-bold placeholder-red-300 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500 transition-all kill-switch-input" />
                    </div>
                    <button className="bg-red-600 hover:bg-red-700 disabled:bg-red-300 disabled:cursor-not-allowed text-white px-6 py-3 rounded-xl font-bold transition-all flex items-center gap-2 kill-switch-btn" disabled><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" /></svg>
                      Activar Kill Switch
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="lg:col-span-4 space-y-6">
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-heading font-bold text-slate-900">Uso de Créditos</h3>
            <span className="text-xs text-slate-500">Período actual</span>
          </div>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-600">Créditos consumidos</span>
                <span className="font-bold text-slate-900">340 / 1,000</span>
              </div>
              <div className="h-3 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 rounded-full transition-all" style={{width: '34%'}} />
              </div>
              <p className="text-xs text-slate-500 mt-1">34% utilizado · 660 restantes</p>
            </div>
            <div className="h-px bg-slate-100" />
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-600">Mensajes hoy (Autopiloto)</span>
                <span className="font-bold text-amber-600">142 / 200</span>
              </div>
              <div className="h-3 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full bg-amber-500 rounded-full transition-all" style={{width: '71%'}} />
              </div>
              <p className="text-xs text-amber-600 mt-1">⚠ 71% del límite diario</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="font-heading font-bold text-slate-900 mb-4">Desglose de Tokens</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full" />
                <span className="text-sm text-slate-600">Entrada</span>
              </div>
              <span className="text-sm font-medium text-slate-900">45,230</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                <span className="text-sm text-slate-600">Salida</span>
              </div>
              <span className="text-sm font-medium text-slate-900">12,890</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-purple-500 rounded-full" />
                <span className="text-sm text-slate-600">Embeddings</span>
              </div>
              <span className="text-sm font-medium text-slate-900">8,400</span>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-slate-100">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-slate-500">
                  <th className="text-left font-medium pb-2">Modelo</th>
                  <th className="text-right font-medium pb-2">Tokens</th>
                  <th className="text-right font-medium pb-2">Créditos</th>
                </tr>
              </thead>
              <tbody className="text-slate-700">
                <tr>
                  <td className="py-1.5">GPT-4o</td>
                  <td className="text-right">38,120</td>
                  <td className="text-right font-medium">285</td>
                </tr>
                <tr>
                  <td className="py-1.5">GPT-4o-mini</td>
                  <td className="text-right">20,000</td>
                  <td className="text-right font-medium">45</td>
                </tr>
                <tr>
                  <td className="py-1.5">Embeddings</td>
                  <td className="text-right">8,400</td>
                  <td className="text-right font-medium">10</td>
                </tr>
              </tbody>
            </table>
          </div>
          <a href="#" className="mt-4 inline-flex items-center gap-1 text-sm text-emerald-600 hover:text-emerald-700 font-medium">
            Ver facturación
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
          </a>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-heading font-bold text-slate-900">Decisiones Recientes</h3>
            <button className="text-xs text-slate-500 hover:text-slate-700 font-medium">Solo denegadas</button>
          </div>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl">
              <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-700 text-xs font-semibold px-2 py-1 rounded"><svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                Permitido
              </span>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-slate-700 truncate">Cotización producto A enviada</p>
                <p className="text-xs text-slate-500 mt-0.5">Hace 3 min · Auto</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl">
              <span className="inline-flex items-center gap-1 bg-red-100 text-red-700 text-xs font-semibold px-2 py-1 rounded"><svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                Denegado
              </span>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-slate-700 truncate">Descuento 25% solicitado</p>
                <p className="text-xs text-slate-500 mt-0.5">Hace 8 min · Excede límite (10%)</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl">
              <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-700 text-xs font-semibold px-2 py-1 rounded"><svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01" /></svg>
                Escalado
              </span>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-slate-700 truncate">Cliente mencionó "abogado"</p>
                <p className="text-xs text-slate-500 mt-0.5">Hace 15 min · @carlos.m</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl">
              <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-700 text-xs font-semibold px-2 py-1 rounded"><svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                Permitido
              </span>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-slate-700 truncate">Respuesta FAQ enviada</p>
                <p className="text-xs text-slate-500 mt-0.5">Hace 22 min · @maria.l</p>
              </div>
            </div>
          </div>
          <a href="#" className="mt-4 inline-flex items-center gap-1 text-sm text-emerald-600 hover:text-emerald-700 font-medium">
            Ver historial completo
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
          </a>
        </div>
      </div>
    </div>
  </div>
</section>


    );
};

export default AiSettingsViewSectionCustomComponents3;