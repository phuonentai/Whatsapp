(function() {
  const init = () => {
    // Mobile menu toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const mobileMenu = document.querySelector('.mobile-menu');
    if (mobileMenuBtn && mobileMenu) {
      mobileMenuBtn.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
      });
    }

    // Status tabs
    const statusTabs = document.querySelectorAll('.inbox-status-tab');
    statusTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        statusTabs.forEach(t => {
          t.classList.remove('bg-white', 'text-slate-900', 'shadow-sm');
          t.classList.add('text-slate-600');
        });
        tab.classList.add('bg-white', 'text-slate-900', 'shadow-sm');
        tab.classList.remove('text-slate-600');
      });
    });

    // Channel tabs
    const channelTabs = document.querySelectorAll('.inbox-channel-tab');
    channelTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        channelTabs.forEach(t => {
          t.classList.remove('bg-white', 'text-slate-900', 'shadow-sm');
          t.classList.add('text-slate-600');
        });
        tab.classList.add('bg-white', 'text-slate-900', 'shadow-sm');
        tab.classList.remove('text-slate-600');
      });
    });

    // AI rail tabs
    const aiRailTabs = document.querySelectorAll('.ai-rail-tab');
    const aiRailContents = document.querySelectorAll('.ai-rail-content');
    aiRailTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        const targetTab = tab.getAttribute('data-tab');
        aiRailTabs.forEach(t => {
          t.classList.remove('text-emerald-700', 'border-emerald-500', 'bg-emerald-50/50');
          t.classList.add('text-slate-600', 'border-transparent');
        });
        tab.classList.add('text-emerald-700', 'border-emerald-500', 'bg-emerald-50/50');
        tab.classList.remove('text-slate-600', 'border-transparent');
        aiRailContents.forEach(content => {
          if (content.getAttribute('data-content') === targetTab) {
            content.classList.remove('hidden');
          } else {
            content.classList.add('hidden');
          }
        });
      });
    });

    // AI transform dropdown
    const aiTransformBtns = document.querySelectorAll('.ai-transform-btn');
    aiTransformBtns.forEach(btn => {
      const dropdown = btn.closest('.ai-transform-dropdown');
      const menu = dropdown.querySelector('.ai-transform-menu');
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        menu.classList.toggle('hidden');
      });
    });

    document.addEventListener('click', () => {
      document.querySelectorAll('.ai-transform-menu').forEach(menu => {
        menu.classList.add('hidden');
      });
    });

    // AI context expand
    const contextExpandBtns = document.querySelectorAll('.ai-context-expand');
    contextExpandBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const content = btn.nextElementSibling;
        const icon = btn.querySelector('svg');
        content.classList.toggle('hidden');
        if (!content.classList.contains('hidden')) {
          icon.style.transform = 'rotate(90deg)';
        } else {
          icon.style.transform = 'rotate(0deg)';
        }
      });
    });

    // Conversation item selection
    const conversationItems = document.querySelectorAll('.conversation-item');
    conversationItems.forEach(item => {
      item.addEventListener('click', () => {
        conversationItems.forEach(i => {
          i.classList.remove('bg-emerald-50', 'border-l-4', 'border-emerald-500');
        });
        item.classList.add('bg-emerald-50', 'border-l-4', 'border-emerald-500');
      });
    });

    // Send button feedback
    const sendBtns = document.querySelectorAll('.send-btn');
    sendBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        btn.classList.add('scale-95');
        setTimeout(() => {
          btn.classList.remove('scale-95');
        }, 150);
      });
    });
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();