(function() {
  const init = () => {
    const section = document.querySelector('#onboarding');
    if (!section) return;

    let currentStep = 1;
    const totalSteps = 5;
    let isAnimating = false;

    const updateProgress = () => {
      const progressBar = section.querySelector('.progress-bar');
      const currentStepEl = section.querySelector('.current-step');
      if (progressBar) progressBar.style.width = `${(currentStep / totalSteps) * 100}%`;
      if (currentStepEl) currentStepEl.textContent = currentStep;
    };

    const showStep = (step, direction = 'next') => {
      if (isAnimating) return;
      isAnimating = true;

      const pages = section.querySelectorAll('.step-page');
      const currentPage = section.querySelector('.step-page.active');
      const nextPage = section.querySelector(`.step-page[data-step="${step}"]`);

      if (!currentPage || !nextPage) {
        isAnimating = false;
        return;
      }

      const exitClass = direction === 'next' ? 'exit-left' : 'exit-right';
      const enterClass = direction === 'next' ? 'enter-right' : 'enter-left';

      currentPage.classList.add(exitClass);

      setTimeout(() => {
        currentPage.classList.remove('active', exitClass);
        currentPage.classList.add('hidden');

        nextPage.classList.remove('hidden');
        nextPage.classList.add('active', enterClass);

        setTimeout(() => {
          nextPage.classList.remove(enterClass);
          isAnimating = false;
        }, 500);
      }, 400);

      currentStep = step;
      updateProgress();
    };

    // Next buttons
    section.querySelectorAll('.step-next').forEach(btn => {
      btn.addEventListener('click', () => {
        if (currentStep < totalSteps) {
          showStep(currentStep + 1, 'next');
        }
      });
    });

    // Prev buttons
    section.querySelectorAll('.step-prev').forEach(btn => {
      btn.addEventListener('click', () => {
        if (currentStep > 1) {
          showStep(currentStep - 1, 'prev');
        }
      });
    });

    // Regime buttons
    section.querySelectorAll('.regime-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        section.querySelectorAll('.regime-btn').forEach(b => {
          b.classList.remove('active', 'bg-emerald-500/20', 'border-emerald-500', 'text-emerald-300');
          b.classList.add('bg-slate-900', 'border-slate-600', 'text-slate-400');
        });
        btn.classList.remove('bg-slate-900', 'border-slate-600', 'text-slate-400');
        btn.classList.add('active', 'bg-emerald-500/20', 'border-emerald-500', 'text-emerald-300');
      });
    });

    // WhatsApp options
    section.querySelectorAll('.whatsapp-option').forEach(opt => {
      opt.addEventListener('click', () => {
        section.querySelectorAll('.whatsapp-option').forEach(o => {
          o.classList.remove('active', 'bg-emerald-500/10', 'border-emerald-500');
          o.classList.add('bg-slate-900', 'border-slate-600');
          const icon = o.querySelector('.w-10');
          if (icon) {
            icon.classList.remove('bg-emerald-500');
            icon.classList.add('bg-slate-600');
          }
        });
        opt.classList.remove('bg-slate-900', 'border-slate-600');
        opt.classList.add('active', 'bg-emerald-500/10', 'border-emerald-500');
        const activeIcon = opt.querySelector('.w-10');
        if (activeIcon) {
          activeIcon.classList.remove('bg-slate-600');
          activeIcon.classList.add('bg-emerald-500');
        }
      });
    });

    // Product type buttons
    section.querySelectorAll('.product-type-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        section.querySelectorAll('.product-type-btn').forEach(b => {
          b.classList.remove('bg-emerald-500/20', 'border-emerald-500', 'text-emerald-300');
          b.classList.add('bg-slate-900', 'border-slate-600', 'text-slate-400');
        });
        btn.classList.remove('bg-slate-900', 'border-slate-600', 'text-slate-400');
        btn.classList.add('bg-emerald-500/20', 'border-emerald-500', 'text-emerald-300');
      });
    });

    // Upload zone
    const uploadZone = section.querySelector('.upload-zone');
    if (uploadZone) {
      uploadZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadZone.classList.add('drag-over');
      });
      uploadZone.addEventListener('dragleave', () => {
        uploadZone.classList.remove('drag-over');
      });
      uploadZone.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadZone.classList.remove('drag-over');
      });
      uploadZone.addEventListener('click', () => {
        // Simulate file input click
      });
    }

    // Dashboard button
    const dashboardBtn = section.querySelector('.dashboard-btn');
    if (dashboardBtn) {
      dashboardBtn.addEventListener('click', () => {
        alert('¡Bienvenido a tu dashboard! Redirigiendo...');
      });
    }
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();