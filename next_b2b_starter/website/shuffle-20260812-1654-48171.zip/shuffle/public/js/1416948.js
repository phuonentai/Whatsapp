(function() {
  const init = () => {
    // Conversation item click handler
    const conversationItems = document.querySelectorAll('.conversation-item');
    conversationItems.forEach(item => {
      item.addEventListener('click', function() {
        // Remove active state from all items
        conversationItems.forEach(i => {
          i.classList.remove('bg-emerald-50/30', 'border-l-4', 'border-l-emerald-500');
        });
        // Add active state to clicked item
        this.classList.add('bg-emerald-50/30', 'border-l-4', 'border-l-emerald-500');
      });
    });

    // Search input focus effect
    const searchInput = document.querySelector('input[type="text"]');
    if (searchInput) {
      searchInput.addEventListener('focus', function() {
        this.closest('.relative').classList.add('ring-2', 'ring-emerald-500', 'ring-offset-2', 'rounded-lg');
      });
      searchInput.addEventListener('blur', function() {
        this.closest('.relative').classList.remove('ring-2', 'ring-emerald-500', 'ring-offset-2', 'rounded-lg');
      });
    }

    // Select styling enhancement
    const selects = document.querySelectorAll('select');
    selects.forEach(select => {
      select.addEventListener('change', function() {
        this.classList.add('border-emerald-300');
        setTimeout(() => {
          this.classList.remove('border-emerald-300');
        }, 1000);
      });
    });
  };
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();